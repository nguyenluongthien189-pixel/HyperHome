package com.hyperdev.HyperHome.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import com.hyperdev.HyperHome.config.HyperHome;
import com.hyperdev.HyperHome.database.Storage;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class MainMenu {
   private final HyperHome plugin;

   public MainMenu(HyperHome plugin) {
      this.plugin = plugin;
   }

   public void openMenu(Player player) {
      FileConfiguration cfg = this.plugin.getGuiManager().getConfig("mainmenu");
      String title = cfg.getString("title", "§8ʏᴏᴜʀ ʜᴏᴍᴇs");
      List<String> layout = cfg.getStringList("layout");
      int size = layout.size() * 9;
      Inventory inv = Bukkit.createInventory(player, size, this.plugin.getGuiManager().comp(title));
      UUID uuid = player.getUniqueId();
      int maxHomes = this.plugin.getConfigManager().getMaxHomes(player);
      int currentHomes = Storage.getHomeCount(uuid);
      List<Integer> bedSlots = new ArrayList();
      List<Integer> dyeSlots = new ArrayList();
      char bedSymbol = cfg.getString("symbols.bed", "b").charAt(0);
      char dyeSymbol = cfg.getString("symbols.dye", "d").charAt(0);
      int slotCounter = 0;

      for(String row : layout) {
         row = row.replaceAll("\\s+", "");

         for(char c : row.toCharArray()) {
            if (c == bedSymbol) {
               bedSlots.add(slotCounter);
            } else if (c == dyeSymbol) {
               dyeSlots.add(slotCounter);
            }

            ++slotCounter;
         }
      }

      int totalAvailable = Math.min(bedSlots.size(), dyeSlots.size());

      for(int i = 0; i < totalAvailable; ++i) {
         int index = i + 1;
         int bSlot = (Integer)bedSlots.get(i);
         int dSlot = (Integer)dyeSlots.get(i);
         boolean hasHome = Storage.getHome(uuid, index) != null;
         boolean lockedExisting = Storage.isHomeLocked(uuid, index, maxHomes);
         boolean cannotCreateNew = !hasHome && currentHomes >= maxHomes;
         boolean limitReached = lockedExisting || cannotCreateNew;
         String state = limitReached ? "no-perm" : (hasHome ? "has-home" : "no-home");
         this.setupItem(inv, uuid, index, bSlot, "bed", state, hasHome);
         this.setupItem(inv, uuid, index, dSlot, "dye", state, hasHome);
      }

      player.openInventory(inv);
   }

   private void setupItem(Inventory inv, UUID uuid, int index, int slot, String type, String state, boolean hasHome) {
      FileConfiguration cfg = this.plugin.getGuiManager().getConfig("mainmenu");
      String path = "states." + state + "." + type;
      String matName = cfg.getString(path + ".material", "STONE");
      if (type.equals("bed") && state.equals("has-home")) {
         Material custom = Storage.getHomeMaterial(uuid, index);
         if (custom != null) {
            matName = custom.name();
         } else {
            matName = cfg.getString(path + ".fallback-material", "YELLOW_BED");
         }
      }

      Material mat = Material.matchMaterial(matName);
      if (mat == null) {
         mat = Material.STONE;
      }

      ItemStack item = new ItemStack(mat);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         String customName = Storage.getHomeName(uuid, index);
         String rawName = customName != null && !customName.trim().isEmpty() ? customName : "home " + index;
         String smallCapsName = this.plugin.getGuiManager().toSmallCaps(rawName);
         Location homeLoc = Storage.getHome(uuid, index);
         String formattedWorld = "";
         if (homeLoc != null && homeLoc.getWorld() != null) {
            formattedWorld = this.plugin.getGuiManager().formatWorldName(homeLoc.getWorld().getName());
         }

         String name = cfg.getString(path + ".name", "");
         name = name.replace("%home_name_smallcaps%", smallCapsName).replace("%home%", String.valueOf(index)).replace("%world_home%", formattedWorld);
         meta.displayName(this.plugin.getGuiManager().comp(name));
         List<String> loreList = cfg.getStringList(path + ".lore");
         List<Component> lore = new ArrayList();
         if (loreList != null) {
            for(String l : loreList) {
               lore.add(this.plugin.getGuiManager().comp(l.replace("%home%", String.valueOf(index)).replace("%world_home%", formattedWorld)));
            }
         }

         meta.lore(lore);
         meta.getPersistentDataContainer().set(new NamespacedKey(this.plugin, "gui_action"), PersistentDataType.STRING, "main_" + type);
         meta.getPersistentDataContainer().set(new NamespacedKey(this.plugin, "home_index"), PersistentDataType.INTEGER, index);
         meta.getPersistentDataContainer().set(new NamespacedKey(this.plugin, "home_state"), PersistentDataType.STRING, state);
         item.setItemMeta(meta);
      }

      inv.setItem(slot, item);
   }
}
