package com.hyperdev.HyperHome.menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import com.hyperdev.HyperHome.config.HyperHome;
import com.hyperdev.HyperHome.database.Storage;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class Delete {
   public static void openMenu(Player player, int homeIndex, HyperHome plugin) {
      FileConfiguration cfg = plugin.getGuiManager().getConfig("delete");
      Inventory inv = Bukkit.createInventory(player, InventoryType.HOPPER, plugin.getGuiManager().comp(cfg.getString("title", "§8ᴅᴇʟᴇᴛᴇ")));
      UUID uuid = player.getUniqueId();
      String layoutStr = ((String)cfg.getStringList("layout").get(0)).replaceAll("\\s+", "");
      Map<Character, String> symbolMap = new HashMap();
      if (cfg.getConfigurationSection("items") != null) {
         for(String key : cfg.getConfigurationSection("items").getKeys(false)) {
            String sym = cfg.getString("items." + key + ".symbol");
            if (sym != null && !sym.isEmpty()) {
               symbolMap.put(sym.charAt(0), key);
            }
         }
      }

      int slot = 0;

      for(char c : layoutStr.toCharArray()) {
         if (c == '#') {
            ++slot;
         } else {
            if (c == 'h') {
               Material mat = Storage.getHomeMaterial(uuid, homeIndex);
               if (mat == null) {
                  mat = Material.YELLOW_BED;
               }

               ItemStack bed = new ItemStack(mat);
               ItemMeta bedMeta = bed.getItemMeta();
               if (bedMeta != null) {
                  String customName = Storage.getHomeName(uuid, homeIndex);
                  String rawName = customName != null && !customName.trim().isEmpty() ? customName : "home " + homeIndex;
                  bedMeta.displayName(plugin.getGuiManager().comp("&#FFEE00" + plugin.getGuiManager().toSmallCaps(rawName)));
                  bedMeta.getPersistentDataContainer().set(new NamespacedKey(plugin, "gui_action"), PersistentDataType.STRING, "none");
                  bedMeta.getPersistentDataContainer().set(new NamespacedKey(plugin, "home_index"), PersistentDataType.INTEGER, homeIndex);
                  bed.setItemMeta(bedMeta);
               }

               inv.setItem(slot, bed);
            } else {
               String key = (String)symbolMap.get(c);
               if (key != null) {
                  String path = "items." + key;
                  Material mat = Material.matchMaterial(cfg.getString(path + ".material", "STONE"));
                  ItemStack item = new ItemStack(mat != null ? mat : Material.STONE);
                  ItemMeta meta = item.getItemMeta();
                  if (meta != null) {
                     String name = cfg.getString(path + ".name", "").replace("%home%", String.valueOf(homeIndex));
                     meta.displayName(plugin.getGuiManager().comp(name));
                     List<Component> lore = new ArrayList();

                     for(String l : cfg.getStringList(path + ".lore")) {
                        lore.add(plugin.getGuiManager().comp(l.replace("%home%", String.valueOf(homeIndex))));
                     }

                     meta.lore(lore);
                     String action = key.equalsIgnoreCase("cancel") ? "delete_cancel" : "delete_confirm";
                     meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "gui_action"), PersistentDataType.STRING, action);
                     meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "home_index"), PersistentDataType.INTEGER, homeIndex);
                     item.setItemMeta(meta);
                  }

                  inv.setItem(slot, item);
               }
            }

            ++slot;
         }
      }

      player.openInventory(inv);
   }
}
