package com.hyperdev.HyperHome.menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.hyperdev.HyperHome.config.HyperHome;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class Manage {
   public static void openMenu(Player player, int homeIndex, HyperHome plugin) {
      FileConfiguration cfg = plugin.getGuiManager().getConfig("manage");
      Inventory inv = Bukkit.createInventory(player, InventoryType.HOPPER, plugin.getGuiManager().comp(cfg.getString("title", "§8ᴍᴀɴᴀɢᴇ ʜᴏᴍᴇ")));
      String layoutStr = (String)cfg.getStringList("layout").get(0);
      Map<Character, String> symbolMap = new HashMap();
      if (cfg.getConfigurationSection("items") != null) {
         for(String key : cfg.getConfigurationSection("items").getKeys(false)) {
            String sym = cfg.getString("items." + key + ".symbol");
            if (sym != null && !sym.isEmpty()) {
               symbolMap.put(sym.charAt(0), key);
            }
         }
      }

      int slot = 0;

      for(char c : layoutStr.toCharArray()) {
         if (c == '#') {
            ++slot;
         } else {
            String key = (String)symbolMap.get(c);
            if (key != null) {
               String path = "items." + key;
               Material mat = Material.matchMaterial(cfg.getString(path + ".material", "STONE"));
               ItemStack item = new ItemStack(mat != null ? mat : Material.STONE);
               ItemMeta meta = item.getItemMeta();
               if (meta != null) {
                  meta.displayName(plugin.getGuiManager().comp(cfg.getString(path + ".name")));
                  List<Component> lore = new ArrayList();

                  for(String l : cfg.getStringList(path + ".lore")) {
                     lore.add(plugin.getGuiManager().comp(l));
                  }

                  meta.lore(lore);
                  String var10000;
                  switch (key.toLowerCase()) {
                     case "coordinate" -> var10000 = "manage_coord";
                     case "rename" -> var10000 = "manage_rename";
                     case "material" -> var10000 = "manage_material";
                     case "teleport" -> var10000 = "manage_teleport";
                     default -> var10000 = "none";
                  }

                  String action = var10000;
                  meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "gui_action"), PersistentDataType.STRING, action);
                  meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "home_index"), PersistentDataType.INTEGER, homeIndex);
                  item.setItemMeta(meta);
               }

               inv.setItem(slot, item);
            }

            ++slot;
         }
      }

      player.openInventory(inv);
   }
}
