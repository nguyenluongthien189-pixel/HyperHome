package com.hyperdev.HyperHome.menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.hyperdev.HyperHome.config.HyperHome;
import com.hyperdev.HyperHome.config.GuiManager;
import com.hyperdev.HyperHome.features.MaterialLib;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class Materials {
   public static void openMenu(Player player, int homeIndex, int page, HyperHome plugin) {
      FileConfiguration cfg = plugin.getGuiManager().getConfig("materials");
      Inventory inv = Bukkit.createInventory(player, 54, plugin.getGuiManager().comp(cfg.getString("title", "§8ᴍᴀᴛᴇʀɪᴀʟ ᴅɪsᴘʟᴀʏ")));
      NamespacedKey homeKey = new NamespacedKey(plugin, "home_index");
      NamespacedKey pageKey = new NamespacedKey(plugin, "page");
      NamespacedKey actionKey = new NamespacedKey(plugin, "gui_action");
      List<Material> mats = MaterialLib.getMaterials();
      int startIndex = page * 45;
      int endIndex = Math.min(startIndex + 45, mats.size());

      for(int i = startIndex; i < endIndex; ++i) {
         ItemStack item = new ItemStack((Material)mats.get(i));
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            GuiManager var10001 = plugin.getGuiManager();
            Object var10002 = mats.get(i);
            meta.displayName(var10001.comp("&f" + formatMaterialName(((Material)var10002).name())));
            meta.getPersistentDataContainer().set(homeKey, PersistentDataType.INTEGER, homeIndex);
            meta.getPersistentDataContainer().set(actionKey, PersistentDataType.STRING, "material_select");
            item.setItemMeta(meta);
         }

         inv.setItem(i - startIndex, item);
      }

      String layoutStr = (String)cfg.getStringList("layout").get(0);
      Map<Character, String> symbolMap = new HashMap();
      if (cfg.getConfigurationSection("items") != null) {
         for(String key : cfg.getConfigurationSection("items").getKeys(false)) {
            String sym = cfg.getString("items." + key + ".symbol");
            if (sym != null && !sym.isEmpty()) {
               symbolMap.put(sym.charAt(0), key);
            }
         }
      }

      int slot = 45;

      for(char c : layoutStr.toCharArray()) {
         if (c == '#') {
            ++slot;
         } else {
            String key = (String)symbolMap.get(c);
            if (key != null) {
               if (key.equalsIgnoreCase("previous") && page == 0) {
                  ++slot;
                  continue;
               }

               if (key.equalsIgnoreCase("next") && endIndex >= mats.size()) {
                  ++slot;
                  continue;
               }

               String path = "items." + key;
               Material mat = Material.matchMaterial(cfg.getString(path + ".material", "ARROW"));
               ItemStack item = new ItemStack(mat != null ? mat : Material.ARROW);
               ItemMeta meta = item.getItemMeta();
               if (meta != null) {
                  meta.displayName(plugin.getGuiManager().comp(cfg.getString(path + ".name")));
                  List<Component> lore = new ArrayList();

                  for(String l : cfg.getStringList(path + ".lore")) {
                     lore.add(plugin.getGuiManager().comp(l));
                  }

                  meta.lore(lore);
                  meta.getPersistentDataContainer().set(homeKey, PersistentDataType.INTEGER, homeIndex);
                  meta.getPersistentDataContainer().set(actionKey, PersistentDataType.STRING, "material_page");
                  int targetPage = key.equalsIgnoreCase("previous") ? page - 1 : page + 1;
                  meta.getPersistentDataContainer().set(pageKey, PersistentDataType.INTEGER, targetPage);
                  item.setItemMeta(meta);
               }

               inv.setItem(slot, item);
            }

            ++slot;
         }
      }

      player.openInventory(inv);
   }

   private static String formatMaterialName(String name) {
      String[] words = name.toLowerCase().split("_");
      StringBuilder sb = new StringBuilder();

      for(String w : words) {
         if (!w.isEmpty()) {
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(" ");
         }
      }

      return sb.toString().trim();
   }
}
