package com.hyperdev.HyperHome.config;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class ConfigManager {
   private final HyperHome plugin;
   private File file;
   private FileConfiguration config;
   private String languageFile;
   private int teleportTime;
   private boolean teleportEffects;
   private String adminPerm;
   private Map<String, Integer> homeLimits;
   private List<String> blacklistWorlds;

   public ConfigManager(HyperHome plugin) {
      this.plugin = plugin;
      this.loadConfig();
   }

   public void loadConfig() {
      this.file = new File(this.plugin.getDataFolder(), "settings.yml");
      if (!this.file.exists()) {
         this.plugin.getDataFolder().mkdirs();
         this.plugin.saveResource("settings.yml", false);
      }

      this.config = YamlConfiguration.loadConfiguration(this.file);
      this.languageFile = this.config.getString("language", "Vi.yml");
      this.teleportTime = this.config.getInt("teleport-time", 5);
      this.teleportEffects = this.config.getBoolean("teleport-effects", true);
      this.adminPerm = this.config.getString("permissions.home-admin", "home.admin");
      this.blacklistWorlds = this.config.getStringList("blacklist");
      this.homeLimits = new HashMap();
      List<String> limits = this.config.getStringList("permissions.home-limits");
      if (limits != null) {
         for(String limit : limits) {
            String[] parts = limit.split(":");
            if (parts.length == 3) {
               try {
                  this.homeLimits.put(parts[1], Integer.parseInt(parts[2]));
               } catch (NumberFormatException var6) {
               }
            }
         }
      }

   }

   public int getMaxHomes(Player player) {
      if (player.hasPermission(this.adminPerm)) {
         return 999;
      } else {
         int max = 0;

         for(Map.Entry<String, Integer> entry : this.homeLimits.entrySet()) {
            if (player.hasPermission((String)entry.getKey()) && (Integer)entry.getValue() > max) {
               max = (Integer)entry.getValue();
            }
         }

         return max;
      }
   }

   public int getTeleportTime() {
      return this.teleportTime;
   }

   public boolean hasTeleportEffects() {
      return this.teleportEffects;
   }

   public String getLanguageFile() {
      return this.languageFile;
   }

   public List<String> getBlacklistWorlds() {
      return this.blacklistWorlds;
   }
}
