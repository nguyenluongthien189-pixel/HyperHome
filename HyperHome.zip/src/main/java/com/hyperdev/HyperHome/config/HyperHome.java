package com.hyperdev.HyperHome.config;

import com.hyperdev.HyperHome.command.HomeCommand;
import com.hyperdev.HyperHome.command.ReloadCommand;
import com.hyperdev.HyperHome.database.Storage;
import com.hyperdev.HyperHome.features.Blacklist;
import com.hyperdev.HyperHome.features.SignAPI;
import com.hyperdev.HyperHome.features.Teleporting;
import com.hyperdev.HyperHome.listeners.MenuListener;
import com.hyperdev.HyperHome.menu.MainMenu;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class HyperHome extends JavaPlugin {
   private ConfigManager configManager;
   private LanguageManager languageManager;
   private GuiManager guiManager;
   private Storage storage;
   private MainMenu mainMenu;
   private SignAPI signAPI;
   private Blacklist blacklist;

   public void onEnable() {
      this.configManager = new ConfigManager(this);
      this.languageManager = new LanguageManager(this);
      this.guiManager = new GuiManager(this);
      this.blacklist = new Blacklist(this);
      this.storage = new Storage(this);
      this.storage.connect();
      this.mainMenu = new MainMenu(this);
      this.signAPI = new SignAPI(this);
      this.signAPI.register();
      this.getServer().getPluginManager().registerEvents(new MenuListener(this, this.mainMenu), this);
      this.getServer().getPluginManager().registerEvents(new Teleporting(this), this);
      HomeCommand homeCommand = new HomeCommand(this, this.mainMenu);
      PluginCommand cmdHome = this.getCommand("home");
      if (cmdHome != null) {
         cmdHome.setExecutor(homeCommand);
         cmdHome.setTabCompleter(homeCommand);
      }

      PluginCommand cmdSetHome = this.getCommand("sethome");
      if (cmdSetHome != null) {
         cmdSetHome.setExecutor(homeCommand);
      }

      PluginCommand cmdHomes = this.getCommand("homes");
      if (cmdHomes != null) {
         cmdHomes.setExecutor(homeCommand);
         cmdHomes.setTabCompleter(homeCommand);
      }

      PluginCommand cmdDelHome = this.getCommand("delhome");
      if (cmdDelHome != null) {
         cmdDelHome.setExecutor(homeCommand);
         cmdDelHome.setTabCompleter(homeCommand);
      }

      PluginCommand cmdHyperHome = this.getCommand("hyperhome");
      if (cmdHyperHome != null) {
         cmdHyperHome.setExecutor(new ReloadCommand(this));
      }

      Bukkit.getAsyncScheduler().runNow(this, (task) -> {
         for(Player player : Bukkit.getOnlinePlayers()) {
            this.storage.loadPlayerHomesFromDB(player.getUniqueId());
         }

      });
      this.printBanner();
   }

   private void printBanner() {
      String[] banner = new String[]{
         "  _    _                       _   _                     ",
         " | |  | |                     | | | |                    ",
         " | |__| |_   _ _ __   ___ _ __| |_| | ___  _ __ ___   ___ ",
         " |  __  | | | | '_ \\ / _ \\ '__| __| |/ _ \\| '_ ` _ \\ / _ \\",
         " | |  | | |_| | |_) |  __/ |  | |_| | (_) | | | | | |  __/",
         " |_|  |_|\\__, | .__/ \\___|_|   \\__|_|\\___/|_| |_| |_|\\___|",
         "          __/ | |                                        ",
         "         |___/|_|                                        "
      };
      System.out.println();
      for(String line : banner) {
         System.out.println(line);
      }
      System.out.println();
      this.getLogger().info("Version " + this.getDescription().getVersion() + " đã được kích hoạt thành công trên Folia/Canvas!");
      this.getLogger().info("Author: HyperDev, ItzShino");
   }

   public void onDisable() {
      if (this.storage != null) {
         this.storage.disconnect();
      }

      this.getLogger().info("§cHyperHome v1.0 đã được tắt an toàn!");
   }

   public Storage getStorage() {
      return this.storage;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public LanguageManager getLanguageManager() {
      return this.languageManager;
   }

   public GuiManager getGuiManager() {
      return this.guiManager;
   }

   public SignAPI getSignAPI() {
      return this.signAPI;
   }

   public Blacklist getBlacklist() {
      return this.blacklist;
   }

   public void reloadPluginConfig() {
      this.configManager.loadConfig();
      this.languageManager.loadLanguage();
      this.guiManager.loadGuis();
      if (this.storage != null) {
         this.storage.disconnect();
         this.storage.connect();
      }

      Bukkit.getAsyncScheduler().runNow(this, (task) -> {
         for(Player player : Bukkit.getOnlinePlayers()) {
            this.storage.loadPlayerHomesFromDB(player.getUniqueId());
         }

      });
   }
}
