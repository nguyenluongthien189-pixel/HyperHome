package com.hyperdev.HyperHome.config;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class GuiManager {
   private final HyperHome plugin;
   private final Map<String, FileConfiguration> guiConfigs = new HashMap();

   public GuiManager(HyperHome plugin) {
      this.plugin = plugin;
      this.loadGuis();
   }

   public void loadGuis() {
      this.guiConfigs.clear();
      String[] files = new String[]{"mainmenu", "manage", "delete", "materials"};
      File guiFolder = new File(this.plugin.getDataFolder(), "Gui");
      if (!guiFolder.exists()) {
         guiFolder.mkdirs();
      }

      for(String name : files) {
         File file = new File(guiFolder, name + ".yml");
         if (!file.exists()) {
            try {
               this.plugin.saveResource("Gui/" + name + ".yml", false);
            } catch (IllegalArgumentException var11) {
               this.plugin.getLogger().warning("Khong tim thay file mau Gui/" + name + ".yml. Dang tao file moi...");

               try {
                  file.createNewFile();
               } catch (Exception var10) {
               }
            }
         }

         this.guiConfigs.put(name, YamlConfiguration.loadConfiguration(file));
      }

   }

   public FileConfiguration getConfig(String name) {
      return (FileConfiguration)this.guiConfigs.get(name);
   }

   public Component comp(String text) {
      if (text == null) {
         return Component.empty();
      } else {
         Pattern pattern = Pattern.compile("&#([a-fA-F0-9]{6})");
         Matcher matcher = pattern.matcher(text);
         StringBuffer buffer = new StringBuffer();

         while(matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder sb = new StringBuilder("§x");

            for(char c : hex.toCharArray()) {
               sb.append('§').append(c);
            }

            matcher.appendReplacement(buffer, sb.toString());
         }

         matcher.appendTail(buffer);
         String colored = ChatColor.translateAlternateColorCodes('&', buffer.toString());
         return LegacyComponentSerializer.legacySection().deserialize(colored).decoration(TextDecoration.ITALIC, false);
      }
   }

   public String toSmallCaps(String text) {
      if (text == null) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();

         for(char c : text.toCharArray()) {
            switch (Character.toLowerCase(c)) {
               case 'a':
                  sb.append('ᴀ');
                  break;
               case 'b':
                  sb.append('ʙ');
                  break;
               case 'c':
                  sb.append('ᴄ');
                  break;
               case 'd':
                  sb.append('ᴅ');
                  break;
               case 'e':
                  sb.append('ᴇ');
                  break;
               case 'f':
                  sb.append('ғ');
                  break;
               case 'g':
                  sb.append('ɢ');
                  break;
               case 'h':
                  sb.append('ʜ');
                  break;
               case 'i':
                  sb.append('ɪ');
                  break;
               case 'j':
                  sb.append('ᴊ');
                  break;
               case 'k':
                  sb.append('ᴋ');
                  break;
               case 'l':
                  sb.append('ʟ');
                  break;
               case 'm':
                  sb.append('ᴍ');
                  break;
               case 'n':
                  sb.append('ɴ');
                  break;
               case 'o':
                  sb.append('ᴏ');
                  break;
               case 'p':
                  sb.append('ᴘ');
                  break;
               case 'q':
                  sb.append('ǫ');
                  break;
               case 'r':
                  sb.append('ʀ');
                  break;
               case 's':
                  sb.append('s');
                  break;
               case 't':
                  sb.append('ᴛ');
                  break;
               case 'u':
                  sb.append('ᴜ');
                  break;
               case 'v':
                  sb.append('ᴠ');
                  break;
               case 'w':
                  sb.append('ᴡ');
                  break;
               case 'x':
                  sb.append('x');
                  break;
               case 'y':
                  sb.append('ʏ');
                  break;
               case 'z':
                  sb.append('ᴢ');
                  break;
               default:
                  sb.append(c);
            }
         }

         return sb.toString();
      }
   }

   public String formatWorldName(String worldName) {
      if (worldName == null) {
         return "";
      } else {
         String var10000;
         switch (worldName.toLowerCase()) {
            case "world" -> var10000 = "ᴏᴠᴇʀᴡᴏʀʟᴅ";
            case "world_nether" -> var10000 = "ɴᴇᴛʜᴇʀ";
            case "world_the_end" -> var10000 = "ᴛʜᴇ ᴇɴᴅ";
            default -> var10000 = this.toSmallCaps(worldName);
         }

         return var10000;
      }
   }
}
