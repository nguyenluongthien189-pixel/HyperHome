package com.hyperdev.HyperHome.config;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class LanguageManager {
   private final HyperHome plugin;
   private FileConfiguration config;

   public LanguageManager(HyperHome plugin) {
      this.plugin = plugin;
      this.loadLanguage();
   }

   public void loadLanguage() {
      String fileName = this.plugin.getConfigManager().getLanguageFile();
      File file = new File(this.plugin.getDataFolder(), "Language/" + fileName);
      if (!file.exists()) {
         file.getParentFile().mkdirs();

         try {
            this.plugin.saveResource("Language/" + fileName, false);
         } catch (IllegalArgumentException var6) {
            this.plugin.getLogger().warning("Khong tim thay file " + fileName + " trong plugin. Dang tao moi...");

            try {
               file.createNewFile();
            } catch (Exception var5) {
            }
         }
      }

      this.config = YamlConfiguration.loadConfiguration(file);
   }

   public String getMessage(String path, String... placeholders) {
      String prefix = this.config.getString("prefix", "");
      String message = this.config.getString("messages." + path, "Lỗi: Không tìm thấy tin nhắn " + path);
      String fullMessage = prefix + message;

      for(int i = 0; i < placeholders.length; i += 2) {
         if (i + 1 < placeholders.length) {
            fullMessage = fullMessage.replace(placeholders[i], placeholders[i + 1]);
         }
      }

      return this.colorize(fullMessage);
   }

   public Component getActionBar(String path, String... placeholders) {
      String message = this.config.getString("actionbar." + path, "");

      for(int i = 0; i < placeholders.length; i += 2) {
         if (i + 1 < placeholders.length) {
            message = message.replace(placeholders[i], placeholders[i + 1]);
         }
      }

      String colored = this.colorize(message);
      return LegacyComponentSerializer.legacySection().deserialize(colored).decoration(TextDecoration.ITALIC, false);
   }

   private String colorize(String text) {
      if (text == null) {
         return "";
      } else {
         Pattern pattern = Pattern.compile("&#([a-fA-F0-9]{6})");
         Matcher matcher = pattern.matcher(text);
         StringBuffer buffer = new StringBuffer();

         while(matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder sb = new StringBuilder("§x");

            for(char c : hex.toCharArray()) {
               sb.append('§').append(c);
            }

            matcher.appendReplacement(buffer, sb.toString());
         }

         matcher.appendTail(buffer);
         return ChatColor.translateAlternateColorCodes('&', buffer.toString());
      }
   }
}
