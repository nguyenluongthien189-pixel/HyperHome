package com.hyperdev.HyperHome.command;

import com.hyperdev.HyperHome.config.HyperHome;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

public class ReloadCommand implements CommandExecutor {
   private final HyperHome plugin;

   public ReloadCommand(HyperHome plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
      if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
         if (!sender.hasPermission("home.admin")) {
            sender.sendMessage("§cBạn không có quyền sử dụng lệnh này!");
            return true;
         } else {
            this.plugin.reloadPluginConfig();
            sender.sendMessage("§aĐã tải lại cấu hình (homes.yml) plugin HyperHome thành công!");
            return true;
         }
      } else {
         sender.sendMessage("§cSử dụng lệnh: /hyperhome reload");
         return true;
      }
   }
}
