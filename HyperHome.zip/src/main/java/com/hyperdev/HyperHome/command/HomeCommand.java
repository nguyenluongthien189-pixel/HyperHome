package com.hyperdev.HyperHome.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.hyperdev.HyperHome.config.HyperHome;
import com.hyperdev.HyperHome.database.Storage;
import com.hyperdev.HyperHome.features.Teleporting;
import com.hyperdev.HyperHome.menu.MainMenu;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;

public class HomeCommand implements CommandExecutor, TabCompleter {
   private final HyperHome plugin;
   private final MainMenu mainMenu;

   public HomeCommand(HyperHome plugin, MainMenu mainMenu) {
      this.plugin = plugin;
      this.mainMenu = mainMenu;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         String cmdName = command.getName().toLowerCase();
         if (cmdName.equals("sethome")) {
            if (args.length == 0) {
               player.sendMessage("§cSử dụng: /sethome <tên>");
               return true;
            } else {
               String name = String.join(" ", args);
               if (this.plugin.getBlacklist().isBlacklisted(player.getWorld())) {
                  player.sendMessage(this.plugin.getLanguageManager().getMessage("world-blacklisted"));
                  return true;
               } else if (Storage.getIndexByName(player.getUniqueId(), name) != -1) {
                  player.sendMessage(this.plugin.getLanguageManager().getMessage("name-exists"));
                  return true;
               } else {
                  int maxHomes = this.plugin.getConfigManager().getMaxHomes(player);
                  int currentHomes = Storage.getHomeCount(player.getUniqueId());
                  if (currentHomes >= maxHomes) {
                     player.sendMessage(this.plugin.getLanguageManager().getMessage("home-limit-reached"));
                     return true;
                  } else {
                     int emptyIndex = Storage.getFirstEmptyIndex(player.getUniqueId(), maxHomes);
                     if (emptyIndex == -1) {
                        player.sendMessage(this.plugin.getLanguageManager().getMessage("home-limit-reached"));
                        return true;
                     } else {
                        this.plugin.getStorage().saveHome(player.getUniqueId(), emptyIndex, player.getLocation());
                        this.plugin.getStorage().setHomeName(player.getUniqueId(), emptyIndex, name);
                        player.sendMessage(this.plugin.getLanguageManager().getMessage("home-set", "%home%", String.valueOf(emptyIndex)));
                        return true;
                     }
                  }
               }
            }
         } else if (cmdName.equals("delhome")) {
            if (args.length == 0) {
               player.sendMessage("§cSử dụng: /delhome <tên>");
               return true;
            } else {
               String name = String.join(" ", args);
               int index = Storage.getIndexByName(player.getUniqueId(), name);
               if (index != -1) {
                  this.plugin.getStorage().deleteHome(player.getUniqueId(), index);
                  player.sendMessage(this.plugin.getLanguageManager().getMessage("home-deleted", "%home%", String.valueOf(index)));
               } else {
                  player.sendMessage(this.plugin.getLanguageManager().getMessage("home-not-found"));
               }

               return true;
            }
         } else if (!cmdName.equals("home") && !cmdName.equals("homes")) {
            return true;
         } else if (args.length > 0) {
            String name = String.join(" ", args);
            int index = Storage.getIndexByName(player.getUniqueId(), name);
            if (index != -1) {
               Location loc = Storage.getHome(player.getUniqueId(), index);
               if (loc != null) {
                  if (player.getOpenInventory().getTopInventory().getType() != InventoryType.CRAFTING) {
                     player.closeInventory();
                  }

                  Teleporting.startTeleport(player, index, loc, this.plugin);
               }
            } else {
               player.sendMessage(this.plugin.getLanguageManager().getMessage("home-not-found"));
            }

            return true;
         } else {
            if (player.getOpenInventory().getTopInventory().getType() != InventoryType.CRAFTING) {
               player.closeInventory();
            }

            this.mainMenu.openMenu(player);
            return true;
         }
      } else {
         sender.sendMessage(this.plugin.getLanguageManager().getMessage("cmd-only-player"));
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> completions = new ArrayList();
      if (sender instanceof Player player) {
         String cmdName = command.getName().toLowerCase();
         if ((cmdName.equals("home") || cmdName.equals("homes") || cmdName.equals("delhome")) && args.length == 1) {
            Map<Integer, String> names = (Map)Storage.homeNamesCache.get(player.getUniqueId());
            Map<Integer, Location> homes = (Map)Storage.homeCache.get(player.getUniqueId());
            if (homes != null) {
               for(Integer idx : homes.keySet()) {
                  String name = names != null && names.containsKey(idx) ? (String)names.get(idx) : "home " + idx;
                  if (name.toLowerCase().startsWith(args[0].toLowerCase())) {
                     completions.add(name);
                  }
               }
            }
         }
      }

      return completions;
   }
}
