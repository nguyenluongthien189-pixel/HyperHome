package com.hyperdev.HyperHome.listeners;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import com.hyperdev.HyperHome.config.HyperHome;
import com.hyperdev.HyperHome.database.Storage;
import com.hyperdev.HyperHome.features.Teleporting;
import com.hyperdev.HyperHome.menu.Delete;
import com.hyperdev.HyperHome.menu.MainMenu;
import com.hyperdev.HyperHome.menu.Manage;
import com.hyperdev.HyperHome.menu.Materials;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class MenuListener implements Listener {
   private final HyperHome plugin;
   private final MainMenu mainMenu;
   private final Set<UUID> switchingMenu = new HashSet();
   private final Map<UUID, Long> pendingDelete = new HashMap();

   public MenuListener(HyperHome plugin, MainMenu mainMenu) {
      this.plugin = plugin;
      this.mainMenu = mainMenu;
   }

   private String getPlainTitle(String configName) {
      String raw = this.plugin.getGuiManager().getConfig(configName).getString("title", "");
      return PlainTextComponentSerializer.plainText().serialize(this.plugin.getGuiManager().comp(raw));
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> this.plugin.getStorage().loadPlayerHomesFromDB(uuid));
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      Storage.homeCache.remove(uuid);
      Storage.homeNamesCache.remove(uuid);
      Storage.homeMaterialsCache.remove(uuid);
      this.switchingMenu.remove(uuid);
      this.pendingDelete.remove(uuid);
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      String viewTitle = PlainTextComponentSerializer.plainText().serialize(event.getView().title());
      String mainTitle = this.getPlainTitle("mainmenu");
      String manageTitle = this.getPlainTitle("manage");
      String deleteTitle = this.getPlainTitle("delete");
      String matTitle = this.getPlainTitle("materials");
      boolean isManagedGui = viewTitle.equals(mainTitle) || viewTitle.equals(manageTitle) || viewTitle.equals(deleteTitle) || viewTitle.equals(matTitle);
      if (isManagedGui) {
         event.setCancelled(true);
         HumanEntity var9 = event.getWhoClicked();
         if (var9 instanceof Player) {
            Player player = (Player)var9;
            ItemStack item = event.getCurrentItem();
            if (item != null && item.hasItemMeta()) {
               NamespacedKey actionKey = new NamespacedKey(this.plugin, "gui_action");
               if (item.getItemMeta().getPersistentDataContainer().has(actionKey, PersistentDataType.STRING)) {
                  UUID uuid = player.getUniqueId();
                  String action = (String)item.getItemMeta().getPersistentDataContainer().get(actionKey, PersistentDataType.STRING);
                  NamespacedKey homeKey = new NamespacedKey(this.plugin, "home_index");
                  int index = (Integer)item.getItemMeta().getPersistentDataContainer().getOrDefault(homeKey, PersistentDataType.INTEGER, -1);
                  if (index != -1) {
                     switch (action) {
                        case "main_bed":
                        case "main_dye":
                           this.handleMainMenuClick(player, uuid, index, item);
                           break;
                        case "manage_coord":
                           this.playSound(player, "manage", "click", Sound.UI_BUTTON_CLICK);
                           this.switchingMenu.add(uuid);
                           player.closeInventory();
                           Location homeLoc = Storage.getHome(uuid, index);
                           if (homeLoc != null) {
                              String worldName = homeLoc.getWorld() != null ? homeLoc.getWorld().getName() : "";
                              String formattedWorld = this.plugin.getGuiManager().formatWorldName(worldName);
                              Component[] var10000 = new Component[]{Component.text(formattedWorld), Component.text("ᴄᴏᴏʀᴅɪɴᴀᴛᴇ"), null, null};
                              long var10003 = Math.round(homeLoc.getX());
                              var10000[2] = Component.text(var10003 + " " + Math.round(homeLoc.getY()) + " " + Math.round(homeLoc.getZ()));
                              var10000[3] = Component.empty();
                              Component[] lines = var10000;
                              this.plugin.getSignAPI().openSign(player, lines, (res) -> this.mainMenu.openMenu(player));
                           }
                           break;
                        case "manage_rename":
                           this.playSound(player, "manage", "click", Sound.UI_BUTTON_CLICK);
                           this.switchingMenu.add(uuid);
                           player.closeInventory();
                           Component[] lines = new Component[]{Component.empty(), Component.text("^^^^^^^^^"), Component.text("ᴇᴅɪᴛ ɴᴀᴍᴇ"), Component.empty()};
                           this.plugin.getSignAPI().openSign(player, lines, (res) -> {
                              String newName = res[0];
                              if (newName != null && !newName.trim().isEmpty()) {
                                 int existingIndex = Storage.getIndexByName(uuid, newName);
                                 if (existingIndex != -1 && existingIndex != index) {
                                    player.sendMessage(this.plugin.getLanguageManager().getMessage("name-exists"));
                                 } else {
                                    this.plugin.getStorage().setHomeName(uuid, index, newName);
                                    player.sendMessage(this.plugin.getLanguageManager().getMessage("name-updated", "%name%", newName));
                                 }
                              }

                              this.mainMenu.openMenu(player);
                           });
                           break;
                        case "manage_material":
                           this.playSound(player, "manage", "click", Sound.UI_BUTTON_CLICK);
                           this.switchingMenu.add(uuid);
                           Materials.openMenu(player, index, 0, this.plugin);
                           break;
                        case "manage_teleport":
                           this.playSound(player, "manage", "click", Sound.UI_BUTTON_CLICK);
                           Location loc = Storage.getHome(uuid, index);
                           if (loc != null) {
                              this.switchingMenu.add(uuid);
                              player.closeInventory();
                              Teleporting.startTeleport(player, index, loc, this.plugin);
                           }
                           break;
                        case "delete_cancel":
                           this.playSound(player, "delete", "click", Sound.UI_BUTTON_CLICK);
                           this.switchingMenu.add(uuid);
                           this.mainMenu.openMenu(player);
                           break;
                        case "delete_confirm":
                           long now = System.currentTimeMillis();
                           if (this.pendingDelete.containsKey(uuid) && now - (Long)this.pendingDelete.get(uuid) < 5000L) {
                              this.pendingDelete.remove(uuid);
                              this.playSound(player, "delete", "click", Sound.UI_BUTTON_CLICK);
                              this.switchingMenu.add(uuid);
                              this.plugin.getStorage().deleteHome(uuid, index);
                              player.sendMessage(this.plugin.getLanguageManager().getMessage("home-deleted", "%home%", String.valueOf(index)));
                              this.mainMenu.openMenu(player);
                           } else {
                              this.pendingDelete.put(uuid, now);
                              player.sendActionBar(this.plugin.getLanguageManager().getActionBar("delete-confirm"));
                              this.playSound(player, "delete", "click-confirm-warning", Sound.ENTITY_VILLAGER_NO);
                           }
                           break;
                        case "material_page":
                           int targetPage = (Integer)item.getItemMeta().getPersistentDataContainer().getOrDefault(new NamespacedKey(this.plugin, "page"), PersistentDataType.INTEGER, 0);
                           this.playSound(player, "materials", "turn-page", Sound.ITEM_BOOK_PAGE_TURN);
                           this.switchingMenu.add(uuid);
                           Materials.openMenu(player, index, targetPage, this.plugin);
                           break;
                        case "material_select":
                           this.plugin.getStorage().setHomeMaterial(uuid, index, item.getType());
                           this.playSound(player, "materials", "click", Sound.UI_BUTTON_CLICK);
                           player.sendMessage(this.plugin.getLanguageManager().getMessage("material-updated", "%home%", String.valueOf(index)));
                           this.switchingMenu.add(uuid);
                           this.mainMenu.openMenu(player);
                     }

                  }
               }
            }
         }
      }
   }

   private void handleMainMenuClick(Player player, UUID uuid, int index, ItemStack item) {
      String state = (String)item.getItemMeta().getPersistentDataContainer().getOrDefault(new NamespacedKey(this.plugin, "home_state"), PersistentDataType.STRING, "");
      if (state.equals("no-perm")) {
         this.playSound(player, "mainmenu", "click-no-perm", Sound.ENTITY_VILLAGER_NO);
      } else {
         this.playSound(player, "mainmenu", "click-success", Sound.UI_BUTTON_CLICK);
         if (state.equals("has-home")) {
            this.switchingMenu.add(uuid);
            String action = (String)item.getItemMeta().getPersistentDataContainer().get(new NamespacedKey(this.plugin, "gui_action"), PersistentDataType.STRING);
            if ("main_dye".equals(action)) {
               Delete.openMenu(player, index, this.plugin);
            } else {
               Manage.openMenu(player, index, this.plugin);
            }
         } else if (state.equals("no-home")) {
            if (this.plugin.getBlacklist().isBlacklisted(player.getWorld())) {
               player.sendMessage(this.plugin.getLanguageManager().getMessage("world-blacklisted"));
               this.playSound(player, "mainmenu", "click-no-perm", Sound.ENTITY_VILLAGER_NO);
               return;
            }

            this.plugin.getStorage().saveHome(uuid, index, player.getLocation());
            player.sendMessage(this.plugin.getLanguageManager().getMessage("home-set", "%home%", String.valueOf(index)));
            this.switchingMenu.add(uuid);
            this.mainMenu.openMenu(player);
         }

      }
   }

   private void playSound(Player p, String file, String path, Sound def) {
      String sName = this.plugin.getGuiManager().getConfig(file).getString("sounds." + path);
      if (sName != null) {
         try {
            p.playSound(p.getLocation(), Sound.valueOf(sName), 1.0F, 1.0F);
         } catch (Exception var7) {
         }
      } else {
         p.playSound(p.getLocation(), def, 1.0F, 1.0F);
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent event) {
      String viewTitle = PlainTextComponentSerializer.plainText().serialize(event.getView().title());
      String mainTitle = this.getPlainTitle("mainmenu");
      String manageTitle = this.getPlainTitle("manage");
      String deleteTitle = this.getPlainTitle("delete");
      String matTitle = this.getPlainTitle("materials");
      boolean isManagedGui = viewTitle.equals(mainTitle) || viewTitle.equals(manageTitle) || viewTitle.equals(deleteTitle) || viewTitle.equals(matTitle);
      if (isManagedGui) {
         HumanEntity var3 = event.getPlayer();
         if (var3 instanceof Player) {
            Player player = (Player)var3;
            UUID uuid = player.getUniqueId();
            if (this.switchingMenu.contains(uuid)) {
               this.switchingMenu.remove(uuid);
               return;
            }

            if (viewTitle.equals(matTitle)) {
               int homeIndex = 1;
               NamespacedKey homeKey = new NamespacedKey(this.plugin, "home_index");

               for(int i = 0; i < event.getInventory().getSize(); ++i) {
                  ItemStack item = event.getInventory().getItem(i);
                  if (item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(homeKey, PersistentDataType.INTEGER)) {
                     homeIndex = (Integer)item.getItemMeta().getPersistentDataContainer().get(homeKey, PersistentDataType.INTEGER);
                     break;
                  }
               }

               final int finalHomeIndex = homeIndex;
               player.getScheduler().runDelayed(this.plugin, (task) -> {
                  InventoryType currentType = player.getOpenInventory().getType();
                  if (currentType == InventoryType.CRAFTING || currentType == InventoryType.CREATIVE) {
                     Manage.openMenu(player, finalHomeIndex, this.plugin);
                  }

               }, (Runnable)null, 2L);
            } else if (viewTitle.equals(deleteTitle) || viewTitle.equals(manageTitle)) {
               player.getScheduler().runDelayed(this.plugin, (task) -> {
                  InventoryType currentType = player.getOpenInventory().getType();
                  if (currentType == InventoryType.CRAFTING || currentType == InventoryType.CREATIVE) {
                     this.mainMenu.openMenu(player);
                  }

               }, (Runnable)null, 2L);
            }
         }
      }

   }
}
