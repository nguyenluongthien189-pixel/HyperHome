package com.hyperdev.HyperHome.features;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.hyperdev.HyperHome.config.HyperHome;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class Teleporting implements Listener {
   private final HyperHome plugin;
   private static final Map<UUID, TeleportTask> activeTeleports = new ConcurrentHashMap();

   public Teleporting(HyperHome plugin) {
      this.plugin = plugin;
   }

   public static void startTeleport(Player player, int homeIndex, Location targetLocation, HyperHome plugin) {
      UUID uuid = player.getUniqueId();
      if (activeTeleports.containsKey(uuid)) {
         ((TeleportTask)activeTeleports.get(uuid)).cancelInstantly(false);
      }

      TeleportTask task = new TeleportTask(player, homeIndex, targetLocation, plugin);
      activeTeleports.put(uuid, task);
      task.start();
   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      TeleportTask task = (TeleportTask)activeTeleports.get(player.getUniqueId());
      if (task != null) {
         Location from = task.getStartLocation();
         Location to = event.getTo();
         if (to == null || !from.getWorld().equals(to.getWorld()) || from.distance(to) > 0.95) {
            task.cancelDueToMovement();
         }
      }

   }

   @EventHandler
   public void onPlayerDamage(EntityDamageByEntityEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof Player player) {
         TeleportTask task = (TeleportTask)activeTeleports.get(player.getUniqueId());
         if (task != null) {
            Entity damager = event.getDamager();
            if (damager instanceof Player || damager instanceof Mob) {
               task.cancelInstantly(true);
            }
         }
      }

   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      if (activeTeleports.containsKey(uuid)) {
         ((TeleportTask)activeTeleports.get(uuid)).cancelInstantly(false);
      }

   }

   private static class TeleportTask {
      private final Player player;
      private final int homeIndex;
      private final Location startLocation;
      private final Location targetLocation;
      private final HyperHome plugin;
      private ScheduledTask scheduledTask;
      private int secondsLeft;

      public TeleportTask(Player player, int homeIndex, Location targetLocation, HyperHome plugin) {
         this.player = player;
         this.homeIndex = homeIndex;
         this.startLocation = player.getLocation().clone();
         this.targetLocation = targetLocation.clone();
         this.plugin = plugin;
         this.secondsLeft = plugin.getConfigManager().getTeleportTime();
      }

      public Location getStartLocation() {
         return this.startLocation;
      }

      public void start() {
         if (this.plugin.getConfigManager().hasTeleportEffects()) {
            this.player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 300, 0, false, false, false));
            this.player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 300, 0, false, false, false));
         }

         this.scheduledTask = this.player.getScheduler().runAtFixedRate(this.plugin, (task) -> {
            if (this.secondsLeft > 0) {
               this.player.sendActionBar(this.plugin.getLanguageManager().getActionBar("teleporting", "%home%", String.valueOf(this.homeIndex), "%time%", String.valueOf(this.secondsLeft)));
               this.player.playSound(this.player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
               --this.secondsLeft;
            } else {
               Teleporting.activeTeleports.remove(this.player.getUniqueId());
               task.cancel();
               this.removeEffects();
               this.player.teleportAsync(this.targetLocation).thenAccept((success) -> {
                  if (success) {
                     this.plugin.getSignAPI().forceCleanup(this.player.getUniqueId());
                     this.player.sendActionBar(this.plugin.getLanguageManager().getActionBar("teleport-success", "%home%", String.valueOf(this.homeIndex)));
                     this.player.playSound(this.player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                  }

               });
            }

         }, () -> {
         }, 1L, 20L);
      }

      public void cancelDueToMovement() {
         Teleporting.activeTeleports.remove(this.player.getUniqueId());
         if (this.scheduledTask != null) {
            this.scheduledTask.cancel();
         }

         this.removeEffects();
         this.player.getScheduler().runDelayed(this.plugin, (task) -> {
            if (this.player.isOnline()) {
               this.player.sendActionBar(this.plugin.getLanguageManager().getActionBar("teleport-cancel"));
               this.player.playSound(this.player.getLocation(), Sound.ITEM_SHIELD_BREAK, 1.0F, 1.0F);
            }

         }, (Runnable)null, 5L);
      }

      public void cancelInstantly(boolean playBreakSound) {
         Teleporting.activeTeleports.remove(this.player.getUniqueId());
         if (this.scheduledTask != null) {
            this.scheduledTask.cancel();
         }

         this.removeEffects();
         if (playBreakSound && this.player.isOnline()) {
            this.player.playSound(this.player.getLocation(), Sound.ITEM_SHIELD_BREAK, 1.0F, 1.0F);
         }

      }

      private void removeEffects() {
         if (this.plugin.getConfigManager().hasTeleportEffects()) {
            this.player.removePotionEffect(PotionEffectType.SLOWNESS);
            this.player.removePotionEffect(PotionEffectType.DARKNESS);
         }

      }
   }
}
