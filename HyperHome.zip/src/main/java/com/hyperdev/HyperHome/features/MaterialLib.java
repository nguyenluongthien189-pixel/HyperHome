package com.hyperdev.HyperHome.features;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import org.bukkit.Material;

public class MaterialLib {
   private static final List<Material> VALID_MATERIALS = new ArrayList();

   public static List<Material> getMaterials() {
      return VALID_MATERIALS;
   }

   static {
      Stream var10000 = Arrays.stream(Material.values()).filter((mat) -> mat.isItem() && !mat.isAir() && !mat.name().contains("LEGACY_")).sorted((m1, m2) -> {
         if (m1.isBlock() && !m2.isBlock()) {
            return -1;
         } else {
            return !m1.isBlock() && m2.isBlock() ? 1 : m1.name().compareTo(m2.name());
         }
      });
      List var10001 = VALID_MATERIALS;
      Objects.requireNonNull(var10001);
      var10000.forEach(var10001::add);
   }
}
