package com.hyperdev.HyperHome.features;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.sign.Side;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class SignAPI implements Listener {
   private final JavaPlugin plugin;
   private final Map<UUID, SignSession> activeSessions = new ConcurrentHashMap();

   public SignAPI(JavaPlugin plugin) {
      this.plugin = plugin;
   }

   public void register() {
      Bukkit.getPluginManager().registerEvents(this, this.plugin);
   }

   public void forceCleanup(UUID uuid) {
      SignSession session = (SignSession)this.activeSessions.remove(uuid);
      if (session != null) {
         Bukkit.getRegionScheduler().execute(this.plugin, session.location, () -> session.oldState.update(true, false));
      }

   }

   public void openSign(Player player, Component[] lines, Consumer<String[]> onComplete) {
      this.forceCleanup(player.getUniqueId());
      Location loc = player.getLocation().getBlock().getLocation().add((double)0.0F, (double)3.0F, (double)0.0F);
      Bukkit.getRegionScheduler().execute(this.plugin, loc, () -> {
         Block block = loc.getBlock();
         BlockState oldState = block.getState();
         block.setType(Material.OAK_WALL_SIGN, false);
         BlockData patt0$temp = block.getBlockData();
         if (patt0$temp instanceof Directional directional) {
            directional.setFacing(player.getFacing().getOppositeFace());
            block.setBlockData(directional, false);
         }

         BlockState newState = block.getState();
         if (newState instanceof Sign sign) {
            if (lines != null) {
               for(int i = 0; i < 4; ++i) {
                  Component line = (Component)(i < lines.length && lines[i] != null ? lines[i] : Component.empty());
                  sign.getSide(Side.FRONT).line(i, line);
               }

               sign.update(true, false);
            }

            for(Player p : Bukkit.getOnlinePlayers()) {
               if (p != player) {
                  p.sendBlockChange(loc, oldState.getBlockData());
               }
            }

            this.activeSessions.put(player.getUniqueId(), new SignSession(loc, oldState, onComplete));
            player.getScheduler().runDelayed(this.plugin, (task) -> {
               if (player.isOnline()) {
                  player.openSign(sign, Side.FRONT);
               }

            }, (Runnable)null, 4L);
         }

      });
   }

   @EventHandler
   public void onSignChange(SignChangeEvent event) {
      Player player = event.getPlayer();
      SignSession session = (SignSession)this.activeSessions.get(player.getUniqueId());
      if (session != null && event.getBlock().getLocation().equals(session.location)) {
         this.activeSessions.remove(player.getUniqueId());
         Bukkit.getRegionScheduler().execute(this.plugin, session.location, () -> session.oldState.update(true, false));
         String[] result = new String[4];

         for(int i = 0; i < 4; ++i) {
            Component line = event.line(i);
            result[i] = line != null ? PlainTextComponentSerializer.plainText().serialize(line) : "";
         }

         if (session.callback != null) {
            player.getScheduler().run(this.plugin, (task) -> session.callback.accept(result), (Runnable)null);
         }
      }

   }

   @EventHandler
   public void onBlockBreak(BlockBreakEvent event) {
      Location loc = event.getBlock().getLocation();

      for(SignSession session : this.activeSessions.values()) {
         if (session.location.equals(loc)) {
            event.setCancelled(true);
            break;
         }
      }

   }

   @EventHandler
   public void onBlockPhysics(BlockPhysicsEvent event) {
      Location loc = event.getBlock().getLocation();

      for(SignSession session : this.activeSessions.values()) {
         if (session.location.equals(loc)) {
            event.setCancelled(true);
            break;
         }
      }

   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.forceCleanup(event.getPlayer().getUniqueId());
   }

   @EventHandler
   public void onPlayerKick(PlayerKickEvent event) {
      this.forceCleanup(event.getPlayer().getUniqueId());
   }

   @EventHandler
   public void onPlayerTeleport(PlayerTeleportEvent event) {
      this.forceCleanup(event.getPlayer().getUniqueId());
   }

   private static class SignSession {
      Location location;
      BlockState oldState;
      Consumer<String[]> callback;

      public SignSession(Location location, BlockState oldState, Consumer<String[]> callback) {
         this.location = location;
         this.oldState = oldState;
         this.callback = callback;
      }
   }
}
