package com.hyperdev.HyperHome.features;

import java.util.List;
import com.hyperdev.HyperHome.config.HyperHome;
import org.bukkit.World;

public class Blacklist {
   private final HyperHome plugin;

   public Blacklist(HyperHome plugin) {
      this.plugin = plugin;
   }

   public boolean isBlacklisted(World world) {
      List<String> blacklistedWorlds = this.plugin.getConfigManager().getBlacklistWorlds();
      if (blacklistedWorlds != null && !blacklistedWorlds.isEmpty()) {
         for(String w : blacklistedWorlds) {
            if (w.equalsIgnoreCase(world.getName())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }
}
