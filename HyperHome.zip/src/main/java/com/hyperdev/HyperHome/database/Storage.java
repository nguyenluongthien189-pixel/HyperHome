package com.hyperdev.HyperHome.database;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.hyperdev.HyperHome.config.HyperHome;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public class Storage {
   private final HyperHome plugin;
   private Connection connection;
   public static final Map<UUID, Map<Integer, Location>> homeCache = new ConcurrentHashMap();
   public static final Map<UUID, Map<Integer, String>> homeNamesCache = new ConcurrentHashMap();
   public static final Map<UUID, Map<Integer, String>> homeMaterialsCache = new ConcurrentHashMap();

   public Storage(HyperHome plugin) {
      this.plugin = plugin;
   }

   public void connect() {
      File dbFolder = new File(this.plugin.getDataFolder(), "Database");
      if (!dbFolder.exists()) {
         dbFolder.mkdirs();
      }

      try {
         Class.forName("org.sqlite.JDBC");
         File dbFile = new File(dbFolder, "storage.db");
         this.connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
         Statement st = this.connection.createStatement();

         try {
            st.execute("PRAGMA journal_mode = WAL;");
            st.execute("PRAGMA synchronous = NORMAL;");
            st.execute("PRAGMA temp_store = MEMORY;");
            st.execute("CREATE TABLE IF NOT EXISTS player_homes (id INTEGER PRIMARY KEY AUTOINCREMENT, uuid VARCHAR(36) NOT NULL, home_index INTEGER NOT NULL, world VARCHAR(64) NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, yaw FLOAT NOT NULL, pitch FLOAT NOT NULL)");
            st.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_uuid_index ON player_homes (uuid, home_index)");

            try {
               st.execute("ALTER TABLE player_homes ADD COLUMN name VARCHAR(64)");
            } catch (SQLException var8) {
            }

            try {
               st.execute("ALTER TABLE player_homes ADD COLUMN material VARCHAR(64)");
            } catch (SQLException var7) {
            }
         } catch (Throwable var9) {
            if (st != null) {
               try {
                  st.close();
               } catch (Throwable var6) {
                  var9.addSuppressed(var6);
               }
            }

            throw var9;
         }

         if (st != null) {
            st.close();
         }
      } catch (Exception e) {
         this.plugin.getLogger().severe("Khong the ket noi co so du lieu SQLite storage.db!");
         e.printStackTrace();
      }

   }

   public void disconnect() {
      try {
         if (this.connection != null && !this.connection.isClosed()) {
            try {
               Statement st = this.connection.createStatement();

               try {
                  st.execute("PRAGMA wal_checkpoint(FULL);");
               } catch (Throwable var5) {
                  if (st != null) {
                     try {
                        st.close();
                     } catch (Throwable var4) {
                        var5.addSuppressed(var4);
                     }
                  }

                  throw var5;
               }

               if (st != null) {
                  st.close();
               }
            } catch (Exception var6) {
            }

            this.connection.close();
         }

         homeCache.clear();
         homeNamesCache.clear();
         homeMaterialsCache.clear();
      } catch (SQLException e) {
         e.printStackTrace();
      }

   }

   public void loadPlayerHomesFromDB(UUID uuid) {
      Map<Integer, Location> homes = new HashMap();
      Map<Integer, String> names = new HashMap();
      Map<Integer, String> materials = new HashMap();
      String sql = "SELECT * FROM player_homes WHERE uuid = ?";

      try {
         PreparedStatement ps = this.connection.prepareStatement(sql);

         try {
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();

            try {
               while(rs.next()) {
                  int index = rs.getInt("home_index");
                  String worldName = rs.getString("world");
                  double x = rs.getDouble("x");
                  double y = rs.getDouble("y");
                  double z = rs.getDouble("z");
                  float yaw = rs.getFloat("yaw");
                  float pitch = rs.getFloat("pitch");
                  World world = Bukkit.getWorld(worldName);
                  if (world != null) {
                     Location loc = new Location(world, x, y, z, yaw, pitch);
                     homes.put(index, loc);
                  }

                  String customName = rs.getString("name");
                  if (customName != null && !customName.isEmpty()) {
                     names.put(index, customName);
                  }

                  String customMaterial = rs.getString("material");
                  if (customMaterial != null && !customMaterial.isEmpty()) {
                     materials.put(index, customMaterial);
                  }
               }
            } catch (Throwable var23) {
               if (rs != null) {
                  try {
                     rs.close();
                  } catch (Throwable var22) {
                     var23.addSuppressed(var22);
                  }
               }

               throw var23;
            }

            if (rs != null) {
               rs.close();
            }
         } catch (Throwable var24) {
            if (ps != null) {
               try {
                  ps.close();
               } catch (Throwable var21) {
                  var24.addSuppressed(var21);
               }
            }

            throw var24;
         }

         if (ps != null) {
            ps.close();
         }
      } catch (SQLException e) {
         e.printStackTrace();
      }

      homeCache.put(uuid, new ConcurrentHashMap(homes));
      homeNamesCache.put(uuid, new ConcurrentHashMap(names));
      homeMaterialsCache.put(uuid, new ConcurrentHashMap(materials));
   }

   public void saveHome(UUID uuid, int index, Location loc) {
      ((Map)homeCache.computeIfAbsent(uuid, (k) -> new ConcurrentHashMap())).put(index, loc);
      Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
         String sql = "INSERT OR REPLACE INTO player_homes (uuid, home_index, world, x, y, z, yaw, pitch) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

         try {
            PreparedStatement ps = this.connection.prepareStatement(sql);

            try {
               ps.setString(1, uuid.toString());
               ps.setInt(2, index);
               ps.setString(3, loc.getWorld() != null ? loc.getWorld().getName() : "world");
               ps.setDouble(4, loc.getX());
               ps.setDouble(5, loc.getY());
               ps.setDouble(6, loc.getZ());
               ps.setFloat(7, loc.getYaw());
               ps.setFloat(8, loc.getPitch());
               ps.executeUpdate();
            } catch (Throwable var10) {
               if (ps != null) {
                  try {
                     ps.close();
                  } catch (Throwable x2) {
                     var10.addSuppressed(x2);
                  }
               }

               throw var10;
            }

            if (ps != null) {
               ps.close();
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }

      });
   }

   public void deleteHome(UUID uuid, int index) {
      if (homeCache.containsKey(uuid)) {
         ((Map)homeCache.get(uuid)).remove(index);
      }

      if (homeNamesCache.containsKey(uuid)) {
         ((Map)homeNamesCache.get(uuid)).remove(index);
      }

      if (homeMaterialsCache.containsKey(uuid)) {
         ((Map)homeMaterialsCache.get(uuid)).remove(index);
      }

      Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
         String sql = "DELETE FROM player_homes WHERE uuid = ? AND home_index = ?";

         try {
            PreparedStatement ps = this.connection.prepareStatement(sql);

            try {
               ps.setString(1, uuid.toString());
               ps.setInt(2, index);
               ps.executeUpdate();
            } catch (Throwable var9) {
               if (ps != null) {
                  try {
                     ps.close();
                  } catch (Throwable x2) {
                     var9.addSuppressed(x2);
                  }
               }

               throw var9;
            }

            if (ps != null) {
               ps.close();
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }

      });
   }

   public void setHomeName(UUID uuid, int index, String name) {
      ((Map)homeNamesCache.computeIfAbsent(uuid, (k) -> new ConcurrentHashMap())).put(index, name);
      Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
         String sql = "UPDATE player_homes SET name = ? WHERE uuid = ? AND home_index = ?";

         try {
            PreparedStatement ps = this.connection.prepareStatement(sql);

            try {
               ps.setString(1, name);
               ps.setString(2, uuid.toString());
               ps.setInt(3, index);
               ps.executeUpdate();
            } catch (Throwable var10) {
               if (ps != null) {
                  try {
                     ps.close();
                  } catch (Throwable x2) {
                     var10.addSuppressed(x2);
                  }
               }

               throw var10;
            }

            if (ps != null) {
               ps.close();
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }

      });
   }

   public void setHomeMaterial(UUID uuid, int index, Material material) {
      ((Map)homeMaterialsCache.computeIfAbsent(uuid, (k) -> new ConcurrentHashMap())).put(index, material.name());
      Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
         String sql = "UPDATE player_homes SET material = ? WHERE uuid = ? AND home_index = ?";

         try {
            PreparedStatement ps = this.connection.prepareStatement(sql);

            try {
               ps.setString(1, material.name());
               ps.setString(2, uuid.toString());
               ps.setInt(3, index);
               ps.executeUpdate();
            } catch (Throwable var10) {
               if (ps != null) {
                  try {
                     ps.close();
                  } catch (Throwable x2) {
                     var10.addSuppressed(x2);
                  }
               }

               throw var10;
            }

            if (ps != null) {
               ps.close();
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }

      });
   }

   public static String getHomeName(UUID uuid, int index) {
      Map<Integer, String> map = (Map)homeNamesCache.get(uuid);
      return map != null ? (String)map.get(index) : null;
   }

   public static Material getHomeMaterial(UUID uuid, int index) {
      Map<Integer, String> map = (Map)homeMaterialsCache.get(uuid);
      if (map != null && map.containsKey(index)) {
         try {
            return Material.valueOf((String)map.get(index));
         } catch (IllegalArgumentException var4) {
         }
      }

      return null;
   }

   public static Location getHome(UUID uuid, int index) {
      Map<Integer, Location> map = (Map)homeCache.get(uuid);
      return map != null ? (Location)map.get(index) : null;
   }

   public static int getHomeCount(UUID uuid) {
      Map<Integer, Location> map = (Map)homeCache.get(uuid);
      return map != null ? map.size() : 0;
   }

   public static boolean isHomeLocked(UUID uuid, int index, int maxHomes) {
      Map<Integer, Location> map = (Map)homeCache.get(uuid);
      if (map != null && map.containsKey(index)) {
         List<Integer> keys = new ArrayList(map.keySet());
         Collections.sort(keys);
         return keys.indexOf(index) >= maxHomes;
      } else {
         return false;
      }
   }

   public static int getFirstEmptyIndex(UUID uuid, int maxHomes) {
      Map<Integer, Location> map = (Map)homeCache.get(uuid);
      int limit = Math.min(maxHomes, 14);

      for(int i = 1; i <= limit; ++i) {
         if (map == null || !map.containsKey(i)) {
            return i;
         }
      }

      return -1;
   }

   public static int getIndexByName(UUID uuid, String name) {
      Map<Integer, String> names = (Map)homeNamesCache.get(uuid);
      if (names != null) {
         for(Map.Entry<Integer, String> entry : names.entrySet()) {
            if (((String)entry.getValue()).equalsIgnoreCase(name)) {
               return (Integer)entry.getKey();
            }
         }
      }

      if (name.toLowerCase().startsWith("home ")) {
         try {
            int idx = Integer.parseInt(name.substring(5));
            if (getHome(uuid, idx) != null) {
               return idx;
            }
         } catch (Exception var5) {
         }
      }

      return -1;
   }
}
