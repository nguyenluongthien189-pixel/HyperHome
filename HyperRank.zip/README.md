# HyperRank

Point currency + Rank shop plugin for Paper/Folia 1.21+, Java 21.

## Build

```
mvn clean package
```

Output jar: `target/HyperRank-1.0.0.jar`.

Requires network access to:
- `repo.papermc.io` (Paper API)
- `repo.tcoded.com` or `jitpack.io` (FoliaLib)
- `repo.luckperms.net` (LuckPerms API)
- `repo.extendedclip.com` (PlaceholderAPI)
- Maven Central (Vault API via JitPack fallback / sqlite-jdbc)

> Note: `com.github.MilkBowl:VaultAPI` is published on JitPack; if it fails to
> resolve from Maven Central, add the JitPack repository (already present in `pom.xml`).

## Install

1. Drop the built jar into `plugins/`.
2. Restart the server. `plugins/HyperRank/config.yml` will be generated.
3. Edit `ranks:` in `config.yml` to match your server's LuckPerms groups and pricing.
4. Optional: install Vault + an economy plugin, LuckPerms, and PlaceholderAPI for
   full functionality (the plugin degrades gracefully if any are missing).

## Commands

| Command | Description | Permission |
|---|---|---|
| `/point` or `/point balance [player]` | Show point balance | `hyperrank.point.use` |
| `/point pay <player> <amount>` | Transfer points | `hyperrank.point.use` |
| `/point give\|take\|set <player> <amount>` | Admin point management | `hyperrank.point.admin` |
| `/rank` | Open the rank shop GUI | `hyperrank.rank.use` |
| `/rank reload` | Reload config.yml | `hyperrank.admin` |

## Placeholders (PlaceholderAPI)

- `%hyperrank_points%` - raw balance
- `%hyperrank_points_formatted%` - balance with thousand separators

## Color codes supported everywhere (chat/lore/GUI titles)

- Legacy: `&a`, `&l`, ...
- Hex: `&#RRGGBB`, `{#RRGGBB}`, `<#RRGGBB>`
- MiniMessage: `<green>`, `<bold>`, `<gradient:#ff0000:#00ff00>`, ...
