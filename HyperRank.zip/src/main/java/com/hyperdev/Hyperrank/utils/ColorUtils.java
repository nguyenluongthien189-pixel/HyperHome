package com.hyperdev.Hyperrank.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Centralised color/format handling for HyperRank.
 * Supports:
 *  - Legacy codes:      &a, &l, &#RRGGBB (Paper's legacy hex extension)
 *  - Bracket hex:       {#RRGGBB}
 *  - Angle-bracket hex: <#RRGGBB>
 *  - Full MiniMessage:  <green>, <bold>, <gradient:#ff0000:#00ff00>, etc.
 *
 * All chat / lore / GUI-title output in the plugin must be routed through here.
 */
public final class ColorUtils {

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY_SERIALIZER =
            LegacyComponentSerializer.builder().hexColors().useUnusualXRepeatedCharacterHexFormat().build();

    private static final Pattern BRACKET_HEX_PATTERN = Pattern.compile("\\{#([A-Fa-f0-9]{6})}");
    private static final Pattern ANGLE_HEX_PATTERN = Pattern.compile("<#([A-Fa-f0-9]{6})>");

    // Heuristic: if the raw string contains a MiniMessage-style tag that isn't just a hex wrapper,
    // we treat it as MiniMessage markup instead of legacy.
    private static final Pattern MINIMESSAGE_TAG_PATTERN =
            Pattern.compile("<(?!#)[a-zA-Z0-9_:#,]+>");

    private ColorUtils() {
    }

    /**
     * Normalises every supported hex syntax down to Paper/Spigot's native legacy hex format
     * (&#RRGGBB), which {@link ChatColor#translateAlternateColorCodes} understands natively
     * on modern Paper builds.
     */
    private static String normalizeHex(String input) {
        String result = input;

        Matcher bracket = BRACKET_HEX_PATTERN.matcher(result);
        result = bracket.replaceAll(m -> "&#" + m.group(1));

        Matcher angle = ANGLE_HEX_PATTERN.matcher(result);
        result = angle.replaceAll(m -> "&#" + m.group(1));

        return result;
    }

    /**
     * Colorizes a single string. Detects whether the string is MiniMessage markup or
     * legacy/hex and dispatches accordingly, always returning a legacy '§'-coded String
     * for compatibility with older API surfaces (item lore, scoreboard, etc.).
     */
    public static String colorize(String message) {
        if (message == null || message.isEmpty()) {
            return message;
        }

        String normalized = normalizeHex(message);
        String legacyTranslated = ChatColor.translateAlternateColorCodes('&', normalized);

        if (containsMiniMessage(legacyTranslated)) {
            Component component = MINI_MESSAGE.deserialize(legacyTranslated);
            return LEGACY_SERIALIZER.serialize(component);
        }

        return legacyTranslated;
    }

    public static List<String> colorize(List<String> messages) {
        if (messages == null) {
            return null;
        }
        return messages.stream().map(ColorUtils::colorize).collect(Collectors.toList());
    }

    /**
     * Converts directly to an Adventure {@link Component}, preferring MiniMessage parsing
     * when the source string looks like MiniMessage markup, otherwise falling back to the
     * legacy serializer (which also understands &#RRGGBB hex codes).
     */
    public static Component toComponent(String message) {
        if (message == null) {
            return Component.empty();
        }

        String normalized = normalizeHex(message);
        String legacyTranslated = ChatColor.translateAlternateColorCodes('&', normalized);

        if (containsMiniMessage(legacyTranslated)) {
            return MINI_MESSAGE.deserialize(legacyTranslated);
        }

        return LEGACY_SERIALIZER.deserialize(legacyTranslated);
    }

    private static boolean containsMiniMessage(String message) {
        return MINIMESSAGE_TAG_PATTERN.matcher(message).find();
    }

    public static String strip(String message) {
        if (message == null) return null;
        return ChatColor.stripColor(colorize(message));
    }
}
