package com.hyperdev.Hyperrank.data;

import com.hyperdev.Hyperrank.HyperRank;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * High-level API for the independent Point currency. Thin wrapper around
 * {@link DataManager} that adds transactional guarantees (no negative balances,
 * atomic pay-to-player transfers).
 */
public final class PointManager {

    private final HyperRank plugin;
    private final DataManager dataManager;

    public PointManager(HyperRank plugin) {
        this.plugin = plugin;
        this.dataManager = plugin.getDataManager();
    }

    public double getPoints(UUID uuid) {
        return dataManager.getCached(uuid);
    }

    public boolean hasEnough(UUID uuid, double amount) {
        return getPoints(uuid) >= amount;
    }

    public CompletableFuture<Void> give(UUID uuid, double amount) {
        double newBalance = getPoints(uuid) + amount;
        return dataManager.setBalance(uuid, newBalance);
    }

    /**
     * Attempts to remove points. Returns a future resolving to {@code true} if the
     * player had a sufficient balance and the deduction succeeded, {@code false} otherwise.
     */
    public CompletableFuture<Boolean> take(UUID uuid, double amount) {
        double current = getPoints(uuid);
        if (current < amount) {
            return CompletableFuture.completedFuture(false);
        }
        return dataManager.setBalance(uuid, current - amount).thenApply(v -> true);
    }

    public CompletableFuture<Void> set(UUID uuid, double amount) {
        return dataManager.setBalance(uuid, amount);
    }

    /**
     * Atomic (best-effort, single-server) transfer between two players.
     */
    public CompletableFuture<Boolean> pay(UUID from, UUID to, double amount) {
        if (amount <= 0 || !hasEnough(from, amount)) {
            return CompletableFuture.completedFuture(false);
        }
        return take(from, amount).thenCompose(success -> {
            if (!success) {
                return CompletableFuture.completedFuture(false);
            }
            return give(to, amount).thenApply(v -> true);
        });
    }
}
