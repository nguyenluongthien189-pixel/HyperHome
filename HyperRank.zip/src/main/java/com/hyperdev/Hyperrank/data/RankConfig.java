package com.hyperdev.Hyperrank.data;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.List;
import java.util.logging.Logger;

/**
 * Immutable snapshot of a single rank entry parsed from config.yml -> ranks.<id>.
 */
public record RankConfig(
        String id,
        String displayName,
        Material material,
        int slot,
        String luckPermsGroup,
        CurrencyType currencyType,
        double costPoint,
        double costVault,
        List<String> lore,
        List<String> rewardCommands
) {

    public enum CurrencyType { POINT, VAULT, BOTH }

    public static RankConfig parse(String id, ConfigurationSection section, Logger logger) {
        String displayName = section.getString("display-name", "&f" + id);

        Material material = Material.matchMaterial(section.getString("material", "STONE"));
        if (material == null) {
            logger.warning("Rank '" + id + "' có material không hợp lệ, dùng mặc định STONE.");
            material = Material.STONE;
        }

        int slot = section.getInt("slot", 0);

        String group = section.getString("luckperms-group", id);

        CurrencyType currencyType;
        try {
            currencyType = CurrencyType.valueOf(section.getString("currency-type", "POINT").toUpperCase());
        } catch (IllegalArgumentException ex) {
            logger.warning("Rank '" + id + "' có currency-type không hợp lệ, dùng mặc định POINT.");
            currencyType = CurrencyType.POINT;
        }

        double costPoint = section.getDouble("cost-point", 0D);
        double costVault = section.getDouble("cost-vault", 0D);
        List<String> lore = section.getStringList("lore");
        List<String> rewards = section.getStringList("rewards-commands");

        return new RankConfig(id, displayName, material, slot, group, currencyType, costPoint, costVault, lore, rewards);
    }

    public boolean requiresPoint() {
        return currencyType == CurrencyType.POINT || currencyType == CurrencyType.BOTH;
    }

    public boolean requiresVault() {
        return currencyType == CurrencyType.VAULT || currencyType == CurrencyType.BOTH;
    }
}
