package com.hyperdev.Hyperrank.data;

import com.hyperdev.Hyperrank.HyperRank;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

import org.bukkit.configuration.file.YamlConfiguration;

/**
 * Handles persistence of player point balances.
 * Two backends are supported (selected via config.yml -> storage.type):
 *   FLATFILE - a single points.yml, cached in memory, flushed periodically/async.
 *   SQLITE   - an embedded points.db with a simple key/value table, also cached.
 *
 * All balances are cached in a {@link ConcurrentHashMap} keyed by player UUID so that
 * reads are always instant and thread-safe; writes go through the async scheduler
 * (via HyperRank#getScheduler) so the main/region thread is never blocked by disk I/O.
 */
public final class DataManager {

    public enum StorageType { FLATFILE, SQLITE }

    private final HyperRank plugin;
    private final StorageType storageType;
    private final Map<UUID, Double> cache = new ConcurrentHashMap<>();
    private final Object ioLock = new Object();

    // Flatfile backend
    private File pointsFile;
    private YamlConfiguration pointsYaml;

    // SQLite backend
    private Connection connection;

    public DataManager(HyperRank plugin) {
        this.plugin = plugin;
        String configured = plugin.getConfig().getString("storage.type", "FLATFILE").toUpperCase();
        StorageType resolved;
        try {
            resolved = StorageType.valueOf(configured);
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("Giá trị storage.type không hợp lệ ('" + configured + "'), dùng mặc định FLATFILE.");
            resolved = StorageType.FLATFILE;
        }
        this.storageType = resolved;

        initBackend();
        loadAll();
    }

    private void initBackend() {
        switch (storageType) {
            case FLATFILE -> initFlatfile();
            case SQLITE -> initSqlite();
        }
    }

    // ---------------------------------------------------------------------
    // FLATFILE backend
    // ---------------------------------------------------------------------

    private void initFlatfile() {
        pointsFile = new File(plugin.getDataFolder(), "points.yml");
        if (!pointsFile.exists()) {
            plugin.getDataFolder().mkdirs();
            try {
                pointsFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Không thể tạo points.yml", e);
            }
        }
        pointsYaml = YamlConfiguration.loadConfiguration(pointsFile);
    }

    private void loadFlatfileAll() {
        synchronized (ioLock) {
            for (String key : pointsYaml.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(key);
                    double points = pointsYaml.getDouble(key, 0D);
                    cache.put(uuid, points);
                } catch (IllegalArgumentException ignored) {
                    // Skip malformed entry.
                }
            }
        }
    }

    private void saveFlatfileAll() {
        synchronized (ioLock) {
            for (Map.Entry<UUID, Double> entry : cache.entrySet()) {
                pointsYaml.set(entry.getKey().toString(), entry.getValue());
            }
            try {
                pointsYaml.save(pointsFile);
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Không thể lưu points.yml", e);
            }
        }
    }

    // ---------------------------------------------------------------------
    // SQLITE backend
    // ---------------------------------------------------------------------

    private void initSqlite() {
        plugin.getDataFolder().mkdirs();
        File dbFile = new File(plugin.getDataFolder(), "points.db");
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            try (Statement statement = connection.createStatement()) {
                statement.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS points (" +
                                "uuid TEXT PRIMARY KEY NOT NULL, " +
                                "balance REAL NOT NULL DEFAULT 0" +
                                ")"
                );
            }
        } catch (ClassNotFoundException | SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Không thể khởi tạo SQLite, chuyển sang FLATFILE.", e);
            initFlatfile();
        }
    }

    private void loadSqliteAll() {
        if (connection == null) {
            return;
        }
        synchronized (ioLock) {
            try (Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery("SELECT uuid, balance FROM points")) {
                while (rs.next()) {
                    try {
                        UUID uuid = UUID.fromString(rs.getString("uuid"));
                        cache.put(uuid, rs.getDouble("balance"));
                    } catch (IllegalArgumentException ignored) {
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Lỗi khi tải dữ liệu SQLite", e);
            }
        }
    }

    private void saveSqliteAll() {
        if (connection == null) {
            return;
        }
        synchronized (ioLock) {
            String upsert = "INSERT INTO points (uuid, balance) VALUES (?, ?) " +
                    "ON CONFLICT(uuid) DO UPDATE SET balance = excluded.balance";
            try (PreparedStatement ps = connection.prepareStatement(upsert)) {
                for (Map.Entry<UUID, Double> entry : cache.entrySet()) {
                    ps.setString(1, entry.getKey().toString());
                    ps.setDouble(2, entry.getValue());
                    ps.addBatch();
                }
                ps.executeBatch();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Lỗi khi lưu dữ liệu SQLite", e);
            }
        }
    }

    // ---------------------------------------------------------------------
    // Public API (cache-backed, thread-safe)
    // ---------------------------------------------------------------------

    public void loadAll() {
        switch (storageType) {
            case FLATFILE -> loadFlatfileAll();
            case SQLITE -> loadSqliteAll();
        }
    }

    /** Runs synchronously off-thread via caller; safe to invoke from an async task. */
    public void saveAll() {
        switch (storageType) {
            case FLATFILE -> saveFlatfileAll();
            case SQLITE -> saveSqliteAll();
        }
    }

    public double getCached(UUID uuid) {
        return cache.getOrDefault(uuid, 0D);
    }

    public void setCached(UUID uuid, double amount) {
        cache.put(uuid, Math.max(0D, amount));
    }

    public CompletableFuture<Double> getBalance(UUID uuid) {
        CompletableFuture<Double> future = new CompletableFuture<>();
        plugin.getScheduler().getScheduler().runAsync(task -> future.complete(getCached(uuid)));
        return future;
    }

    public CompletableFuture<Void> setBalance(UUID uuid, double amount) {
        CompletableFuture<Void> future = new CompletableFuture<>();
        plugin.getScheduler().getScheduler().runAsync(task -> {
            setCached(uuid, amount);
            saveSingle(uuid, amount);
            future.complete(null);
        });
        return future;
    }

    private void saveSingle(UUID uuid, double amount) {
        switch (storageType) {
            case FLATFILE -> {
                synchronized (ioLock) {
                    pointsYaml.set(uuid.toString(), amount);
                    try {
                        pointsYaml.save(pointsFile);
                    } catch (IOException e) {
                        plugin.getLogger().log(Level.SEVERE, "Không thể lưu points.yml", e);
                    }
                }
            }
            case SQLITE -> {
                if (connection == null) return;
                synchronized (ioLock) {
                    String upsert = "INSERT INTO points (uuid, balance) VALUES (?, ?) " +
                            "ON CONFLICT(uuid) DO UPDATE SET balance = excluded.balance";
                    try (PreparedStatement ps = connection.prepareStatement(upsert)) {
                        ps.setString(1, uuid.toString());
                        ps.setDouble(2, amount);
                        ps.executeUpdate();
                    } catch (SQLException e) {
                        plugin.getLogger().log(Level.SEVERE, "Lỗi khi lưu dữ liệu SQLite", e);
                    }
                }
            }
        }
    }

    public void shutdown() {
        saveAll();
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Lỗi khi đóng kết nối SQLite", e);
            }
        }
    }

    public StorageType getStorageType() {
        return storageType;
    }
}
