package com.hyperdev.Hyperrank.hooks;

import com.hyperdev.Hyperrank.HyperRank;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * Thin wrapper around Vault's Economy service. Safe to call even when Vault
 * or an economy plugin isn't present; every method degrades gracefully.
 */
public final class VaultHook {

    private final HyperRank plugin;
    private Economy economy;
    private boolean enabled;

    public VaultHook(HyperRank plugin) {
        this.plugin = plugin;
        setup();
    }

    private void setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Không tìm thấy Vault - các rank dùng currency VAULT/BOTH sẽ bị vô hiệu hóa.");
            enabled = false;
            return;
        }

        RegisteredServiceProvider<Economy> rsp = plugin.getServer()
                .getServicesManager()
                .getRegistration(Economy.class);

        if (rsp == null) {
            plugin.getLogger().warning("Không tìm thấy Economy provider (Vault) - các rank dùng currency VAULT/BOTH sẽ bị vô hiệu hóa.");
            enabled = false;
            return;
        }

        this.economy = rsp.getProvider();
        this.enabled = true;
        plugin.getLogger().info("Đã hook thành công vào Vault Economy (" + economy.getName() + ").");
    }

    public boolean isEnabled() {
        return enabled && economy != null;
    }

    public double getBalance(OfflinePlayer player) {
        if (!isEnabled()) return 0D;
        return economy.getBalance(player);
    }

    public boolean has(OfflinePlayer player, double amount) {
        if (!isEnabled()) return false;
        return economy.has(player, amount);
    }

    public boolean withdraw(OfflinePlayer player, double amount) {
        if (!isEnabled()) return false;
        EconomyResponse response = economy.withdrawPlayer(player, amount);
        return response.transactionSuccess();
    }

    public void deposit(OfflinePlayer player, double amount) {
        if (!isEnabled()) return;
        economy.depositPlayer(player, amount);
    }

    public String format(double amount) {
        if (!isEnabled()) return String.valueOf(amount);
        return economy.format(amount);
    }
}
