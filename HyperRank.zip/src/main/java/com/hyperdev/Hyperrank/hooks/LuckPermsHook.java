package com.hyperdev.Hyperrank.hooks;

import com.hyperdev.Hyperrank.HyperRank;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.types.InheritanceNode;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Integration with the LuckPerms API for granting rank groups. All calls are
 * fully asynchronous via LuckPerms' own {@link net.luckperms.api.model.user.UserManager}
 * CompletableFuture pipeline, matching LuckPerms' own threading contract.
 */
public final class LuckPermsHook {

    private final HyperRank plugin;
    private LuckPerms luckPerms;
    private boolean enabled;

    public LuckPermsHook(HyperRank plugin) {
        this.plugin = plugin;
        setup();
    }

    private void setup() {
        if (plugin.getServer().getPluginManager().getPlugin("LuckPerms") == null) {
            plugin.getLogger().warning("Không tìm thấy LuckPerms - việc gán rank sẽ bị bỏ qua.");
            enabled = false;
            return;
        }
        try {
            this.luckPerms = LuckPermsProvider.get();
            this.enabled = true;
            plugin.getLogger().info("Đã hook thành công vào LuckPerms.");
        } catch (IllegalStateException e) {
            plugin.getLogger().log(Level.WARNING, "LuckPerms chưa sẵn sàng.", e);
            enabled = false;
        }
    }

    public boolean isEnabled() {
        return enabled && luckPerms != null;
    }

    /**
     * Adds an inheritance node (group) to the target player, asynchronously.
     * Completes successfully once LuckPerms has persisted the change.
     */
    public CompletableFuture<Boolean> addGroup(UUID uuid, String groupName) {
        if (!isEnabled()) {
            return CompletableFuture.completedFuture(false);
        }

        return luckPerms.getUserManager().loadUser(uuid).thenCompose(user -> {
            Node node = InheritanceNode.builder(groupName.toLowerCase()).build();
            user.data().add(node);
            return luckPerms.getUserManager().saveUser(user).thenApply(v -> true);
        }).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Lỗi khi gán group LuckPerms cho " + uuid, ex);
            return false;
        });
    }

    public CompletableFuture<Boolean> hasGroup(UUID uuid, String groupName) {
        if (!isEnabled()) {
            return CompletableFuture.completedFuture(false);
        }
        return luckPerms.getUserManager().loadUser(uuid).thenApply(user -> {
            User loaded = user;
            return loaded.getNodes().stream()
                    .filter(n -> n instanceof InheritanceNode)
                    .map(n -> (InheritanceNode) n)
                    .anyMatch(n -> n.getGroupName().equalsIgnoreCase(groupName));
        }).exceptionally(ex -> false);
    }
}
