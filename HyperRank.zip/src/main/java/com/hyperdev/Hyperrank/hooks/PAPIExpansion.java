package com.hyperdev.Hyperrank.hooks;

import com.hyperdev.Hyperrank.HyperRank;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/**
 * Exposes:
 *   %hyperrank_points%            - raw point balance (e.g. "1500.0")
 *   %hyperrank_points_formatted%  - point balance formatted with thousand separators
 */
public final class PAPIExpansion extends PlaceholderExpansion {

    private final HyperRank plugin;

    public PAPIExpansion(HyperRank plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "hyperrank";
    }

    @Override
    public @NotNull String getAuthor() {
        return "HyperDev";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) {
            return "";
        }

        double points = plugin.getPointManager().getPoints(player.getUniqueId());

        return switch (params.toLowerCase()) {
            case "points" -> String.valueOf(points);
            case "points_formatted" -> String.format("%,.0f", points);
            default -> null;
        };
    }
}
