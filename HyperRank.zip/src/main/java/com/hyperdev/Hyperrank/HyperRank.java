package com.hyperdev.Hyperrank;

import com.hyperdev.Hyperrank.commands.PointCommand;
import com.hyperdev.Hyperrank.commands.RankCommand;
import com.hyperdev.Hyperrank.data.DataManager;
import com.hyperdev.Hyperrank.data.PointManager;
import com.hyperdev.Hyperrank.data.RankConfig;
import com.hyperdev.Hyperrank.gui.RankGUI;
import com.hyperdev.Hyperrank.hooks.LuckPermsHook;
import com.hyperdev.Hyperrank.hooks.PAPIExpansion;
import com.hyperdev.Hyperrank.hooks.VaultHook;
import com.hyperdev.Hyperrank.utils.ColorUtils;
import com.tcoded.folialib.FoliaLib;
import com.tcoded.folialib.wrapper.task.WrappedTask;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.LinkedHashMap;
import java.util.Map;

public final class HyperRank extends JavaPlugin {

    private static HyperRank instance;

    private FoliaLib foliaLib;

    private DataManager dataManager;
    private PointManager pointManager;

    private VaultHook vaultHook;
    private LuckPermsHook luckPermsHook;

    private RankGUI rankGUI;
    private final Map<String, RankConfig> ranks = new LinkedHashMap<>();

    private WrappedTask autoSaveTask;

    @Override
    public void onEnable() {
        instance = this;

        this.foliaLib = new FoliaLib(this);

        saveDefaultConfig();

        // --- Core data layer -------------------------------------------------
        this.dataManager = new DataManager(this);
        this.pointManager = new PointManager(this);

        // --- Soft-dependency hooks --------------------------------------------
        this.vaultHook = new VaultHook(this);
        this.luckPermsHook = new LuckPermsHook(this);

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PAPIExpansion(this).register();
            getLogger().info("Đã đăng ký PlaceholderAPI expansion (%hyperrank_points%).");
        }

        // --- Rank shop ---------------------------------------------------------
        loadRanks();
        this.rankGUI = new RankGUI(this);
        getServer().getPluginManager().registerEvents(rankGUI, this);

        // --- Commands ------------------------------------------------------------
        registerCommand("point", new PointCommand(this));
        registerCommand("rank", new RankCommand(this));

        // --- Periodic autosave (Folia-safe async repeating task) -----------------
        long interval = Math.max(20L, getConfig().getLong("settings.save-interval-seconds", 300) * 20L);
        autoSaveTask = foliaLib.getScheduler().runTimerAsync(() -> dataManager.saveAll(), interval, interval);

        getLogger().info("HyperRank đã khởi động thành công! (" + ranks.size() + " rank đã nạp)");
    }

    @Override
    public void onDisable() {
        if (autoSaveTask != null) {
            autoSaveTask.cancel();
        }
        if (dataManager != null) {
            dataManager.shutdown();
        }
        getLogger().info("HyperRank đã tắt.");
    }

    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().severe("Không thể đăng ký lệnh '" + name + "' - kiểm tra plugin.yml!");
            return;
        }
        command.setExecutor(executor);
        if (executor instanceof org.bukkit.command.TabCompleter tabCompleter) {
            command.setTabCompleter(tabCompleter);
        }
    }

    // -------------------------------------------------------------------------
    // Rank config loading
    // -------------------------------------------------------------------------

    public void loadRanks() {
        ranks.clear();
        ConfigurationSection ranksSection = getConfig().getConfigurationSection("ranks");
        if (ranksSection == null) {
            getLogger().warning("Không tìm thấy mục 'ranks' trong config.yml.");
            return;
        }
        for (String id : ranksSection.getKeys(false)) {
            ConfigurationSection section = ranksSection.getConfigurationSection(id);
            if (section == null) continue;
            RankConfig rankConfig = RankConfig.parse(id, section, getLogger());
            ranks.put(id.toLowerCase(), rankConfig);
        }
    }

    public void reload() {
        reloadConfig();
        loadRanks();
        if (rankGUI != null) {
            rankGUI.rebuild();
        }
    }

    // -------------------------------------------------------------------------
    // Message helper
    // -------------------------------------------------------------------------

    public String getMessage(String key, Map<String, String> placeholders) {
        String raw = getConfig().getString("messages." + key, key);
        String prefix = getConfig().getString("settings.prefix", "");
        raw = raw.replace("{prefix}", prefix);
        if (placeholders != null) {
            for (Map.Entry<String, String> entry : placeholders.entrySet()) {
                raw = raw.replace("{" + entry.getKey() + "}", entry.getValue());
            }
        }
        return ColorUtils.colorize(raw);
    }

    public String getMessage(String key) {
        return getMessage(key, null);
    }

    // -------------------------------------------------------------------------
    // Accessors
    // -------------------------------------------------------------------------

    public static HyperRank getInstance() {
        return instance;
    }

    public FoliaLib getScheduler() {
        return foliaLib;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public PointManager getPointManager() {
        return pointManager;
    }

    public VaultHook getVaultHook() {
        return vaultHook;
    }

    public LuckPermsHook getLuckPermsHook() {
        return luckPermsHook;
    }

    public RankGUI getRankGUI() {
        return rankGUI;
    }

    public Map<String, RankConfig> getRanks() {
        return ranks;
    }
}
