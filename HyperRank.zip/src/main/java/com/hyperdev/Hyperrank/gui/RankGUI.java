package com.hyperdev.Hyperrank.gui;

import com.hyperdev.Hyperrank.HyperRank;
import com.hyperdev.Hyperrank.data.RankConfig;
import com.hyperdev.Hyperrank.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Renders the /rank chest shop and drives the full purchase transaction:
 * ownership check -> balance check -> deduction -> LuckPerms grant (async) ->
 * reward commands (global region) -> feedback (sound + broadcast).
 */
public final class RankGUI implements Listener {

    /** Marks inventories that belong to this GUI so we never touch unrelated inventory clicks. */
    private static final class HyperRankHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final HyperRank plugin;
    // Guards against double-click / double-purchase race conditions while a transaction is in flight.
    private final Set<UUID> pendingTransactions = ConcurrentHashMap.newKeySet();

    public RankGUI(HyperRank plugin) {
        this.plugin = plugin;
    }

    public void rebuild() {
        // Config is re-read on demand every time open() is called, nothing to precompute.
    }

    public void open(Player player) {
        int size = plugin.getConfig().getInt("gui.size", 27);
        String title = ColorUtils.colorize(plugin.getMessage("gui-title"));

        Inventory inventory = Bukkit.createInventory(new HyperRankHolder(), size, title);

        ItemStack filler = buildFiller();
        for (int i = 0; i < size; i++) {
            inventory.setItem(i, filler);
        }

        for (RankConfig rank : plugin.getRanks().values()) {
            if (rank.slot() < 0 || rank.slot() >= size) continue;
            inventory.setItem(rank.slot(), buildRankItem(rank));
        }

        int closeSlot = plugin.getConfig().getInt("gui.close-item-slot", size - 5);
        if (closeSlot >= 0 && closeSlot < size) {
            inventory.setItem(closeSlot, buildCloseItem());
        }

        player.openInventory(inventory);
    }

    private ItemStack buildFiller() {
        Material material = Material.matchMaterial(plugin.getConfig().getString("gui.filler-item", "GRAY_STAINED_GLASS_PANE"));
        if (material == null) material = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack buildCloseItem() {
        Material material = Material.matchMaterial(plugin.getConfig().getString("gui.close-item-material", "BARRIER"));
        if (material == null) material = Material.BARRIER;
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtils.colorize(plugin.getConfig().getString("gui.close-item-name", "&cĐóng")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack buildRankItem(RankConfig rank) {
        ItemStack item = new ItemStack(rank.material());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtils.colorize(rank.displayName()));
            meta.setLore(ColorUtils.colorize(rank.lore()));
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof HyperRankHolder)) {
            return;
        }
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) {
            return;
        }

        int slot = event.getSlot();
        RankConfig rank = plugin.getRanks().values().stream()
                .filter(r -> r.slot() == slot)
                .findFirst()
                .orElse(null);

        if (rank == null) {
            // Filler or close button.
            if (slot == plugin.getConfig().getInt("gui.close-item-slot", -1)) {
                player.closeInventory();
            }
            return;
        }

        attemptPurchase(player, rank);
    }

    // -------------------------------------------------------------------------
    // Purchase transaction
    // -------------------------------------------------------------------------

    private void attemptPurchase(Player player, RankConfig rank) {
        UUID uuid = player.getUniqueId();

        if (!pendingTransactions.add(uuid)) {
            return; // Transaction already in flight for this player.
        }

        plugin.getScheduler().getScheduler().runAsync(wrappedTask -> {
            try {
                processPurchase(player, rank);
            } finally {
                pendingTransactions.remove(uuid);
            }
        });
    }

    private void processPurchase(Player player, RankConfig rank) {
        UUID uuid = player.getUniqueId();

        // 1) Ownership check - skip if the player already has this LuckPerms group.
        if (plugin.getLuckPermsHook().isEnabled()) {
            boolean alreadyOwned = plugin.getLuckPermsHook().hasGroup(uuid, rank.luckPermsGroup()).join();
            if (alreadyOwned && !player.hasPermission("hyperrank.rank.bypasscost")) {
                sendMessageSync(player, plugin.getMessage("rank-already-owned"));
                playSoundSync(player, "purchase-fail");
                return;
            }
        }

        boolean bypass = player.hasPermission("hyperrank.rank.bypasscost");

        // 2) Balance checks.
        if (!bypass && rank.requiresPoint()) {
            double points = plugin.getPointManager().getPoints(uuid);
            if (points < rank.costPoint()) {
                sendMessageSync(player, plugin.getMessage("rank-not-enough-point", Map.of(
                        "cost", String.valueOf(rank.costPoint()),
                        "rank", ColorUtils.colorize(rank.displayName())
                )));
                playSoundSync(player, "purchase-fail");
                return;
            }
        }

        if (!bypass && rank.requiresVault()) {
            if (!plugin.getVaultHook().isEnabled() || !plugin.getVaultHook().has(player, rank.costVault())) {
                sendMessageSync(player, plugin.getMessage("rank-not-enough-vault", Map.of(
                        "cost", plugin.getVaultHook().isEnabled() ? plugin.getVaultHook().format(rank.costVault()) : String.valueOf(rank.costVault()),
                        "rank", ColorUtils.colorize(rank.displayName())
                )));
                playSoundSync(player, "purchase-fail");
                return;
            }
        }

        // 3) Deduct currencies.
        if (!bypass && rank.requiresPoint()) {
            boolean taken = plugin.getPointManager().take(uuid, rank.costPoint()).join();
            if (!taken) {
                sendMessageSync(player, plugin.getMessage("rank-not-enough-point", Map.of(
                        "cost", String.valueOf(rank.costPoint()),
                        "rank", ColorUtils.colorize(rank.displayName())
                )));
                playSoundSync(player, "purchase-fail");
                return;
            }
        }
        if (!bypass && rank.requiresVault()) {
            boolean withdrawn = plugin.getVaultHook().withdraw(player, rank.costVault());
            if (!withdrawn) {
                // Refund the point portion if the Vault leg failed (BOTH currency type).
                if (rank.requiresPoint()) {
                    plugin.getPointManager().give(uuid, rank.costPoint()).join();
                }
                sendMessageSync(player, plugin.getMessage("rank-not-enough-vault", Map.of(
                        "cost", plugin.getVaultHook().format(rank.costVault()),
                        "rank", ColorUtils.colorize(rank.displayName())
                )));
                playSoundSync(player, "purchase-fail");
                return;
            }
        }

        // 4) Grant LuckPerms group (async, per LuckPerms' own contract).
        if (plugin.getLuckPermsHook().isEnabled()) {
            boolean granted = plugin.getLuckPermsHook().addGroup(uuid, rank.luckPermsGroup()).join();
            if (!granted) {
                plugin.getLogger().warning("Không thể gán group LuckPerms '" + rank.luckPermsGroup() + "' cho " + player.getName());
            }
        }

        // 5) Run reward console commands on the global region thread (Folia-safe).
        plugin.getScheduler().getScheduler().runNextTick(wrappedTask -> runRewardCommands(player, rank));

        // 6) Feedback.
        sendMessageSync(player, plugin.getMessage("rank-purchase-success", Map.of(
                "rank", ColorUtils.colorize(rank.displayName())
        )));
        playSoundSync(player, "purchase-success");

        String broadcast = plugin.getMessage("rank-broadcast", Map.of(
                "player", player.getName(),
                "rank", ColorUtils.colorize(rank.displayName())
        ));
        plugin.getScheduler().getScheduler().runNextTick(wrappedTask -> Bukkit.broadcastMessage(broadcast));
    }

    private void runRewardCommands(Player player, RankConfig rank) {
        for (String rawCommand : rank.rewardCommands()) {
            String command = rawCommand
                    .replace("{player}", player.getName())
                    .replace("{rank}", ColorUtils.strip(rank.displayName()))
                    .replace("{prefix}", plugin.getConfig().getString("settings.prefix", ""));
            try {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
            } catch (Exception ex) {
                plugin.getLogger().warning("Lỗi khi chạy lệnh thưởng '" + command + "': " + ex.getMessage());
            }
        }
    }

    // -------------------------------------------------------------------------
    // Thread-safe player feedback helpers
    // -------------------------------------------------------------------------

    private void sendMessageSync(Player player, String message) {
        plugin.getScheduler().getScheduler().runAtEntity(player, wrappedTask -> player.sendMessage(message));
    }

    private void playSoundSync(Player player, String soundKey) {
        String soundName = plugin.getConfig().getString("sounds." + soundKey, null);
        if (soundName == null) return;
        try {
            Sound sound = Sound.valueOf(soundName);
            plugin.getScheduler().getScheduler().runAtEntity(player, wrappedTask -> player.playSound(player.getLocation(), sound, 1f, 1f));
        } catch (IllegalArgumentException ignored) {
            // Unknown sound key in config, skip silently.
        }
    }
}
