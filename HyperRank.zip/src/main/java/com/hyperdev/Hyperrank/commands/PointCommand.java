package com.hyperdev.Hyperrank.commands;

import com.hyperdev.Hyperrank.HyperRank;
import com.hyperdev.Hyperrank.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * /point                       - show your own balance
 * /point balance [player]      - show your own or another's balance
 * /point pay <player> <amount> - transfer points to another online/offline player
 * /point give <player> <amount>- (admin) add points
 * /point take <player> <amount>- (admin) remove points
 * /point set <player> <amount> - (admin) set points
 */
public final class PointCommand implements CommandExecutor, TabCompleter {

    private final HyperRank plugin;

    public PointCommand(HyperRank plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("balance")) {
            return handleBalance(sender, args);
        }

        return switch (args[0].toLowerCase()) {
            case "give" -> handleAdminModify(sender, args, Mode.GIVE);
            case "take" -> handleAdminModify(sender, args, Mode.TAKE);
            case "set" -> handleAdminModify(sender, args, Mode.SET);
            case "pay" -> handlePay(sender, args);
            default -> {
                sender.sendMessage(ColorUtils.colorize("&cCú pháp: /point [balance|pay|give|take|set] ..."));
                yield true;
            }
        };
    }

    private enum Mode { GIVE, TAKE, SET }

    private boolean handleBalance(CommandSender sender, String[] args) {
        OfflinePlayer target;

        if (args.length >= 2) {
            target = Bukkit.getOfflinePlayer(args[1]);
            double points = plugin.getPointManager().getPoints(target.getUniqueId());
            sender.sendMessage(plugin.getMessage("point-balance-other", Map.of(
                    "player", target.getName() == null ? args[1] : target.getName(),
                    "points", String.valueOf(points)
            )));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtils.colorize("&cChỉ người chơi mới có thể xem số dư của chính mình."));
            return true;
        }

        double points = plugin.getPointManager().getPoints(player.getUniqueId());
        sender.sendMessage(plugin.getMessage("point-balance", Map.of("points", String.valueOf(points))));
        return true;
    }

    private boolean handleAdminModify(CommandSender sender, String[] args, Mode mode) {
        if (!sender.hasPermission("hyperrank.point.admin")) {
            sender.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage(ColorUtils.colorize("&cCú pháp: /point " + args[0] + " <player> <amount>"));
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(plugin.getMessage("player-not-found", Map.of("player", args[1])));
            return true;
        }

        Double amount = parseAmount(args[2]);
        if (amount == null || amount < 0) {
            sender.sendMessage(plugin.getMessage("invalid-amount"));
            return true;
        }

        UUID uuid = target.getUniqueId();
        String targetName = target.getName() != null ? target.getName() : args[1];

        switch (mode) {
            case GIVE -> plugin.getPointManager().give(uuid, amount).thenRun(() -> {
                sender.sendMessage(plugin.getMessage("point-given", Map.of("amount", String.valueOf(amount), "player", targetName)));
                notifyIfOnline(target, plugin.getMessage("point-received", Map.of("amount", String.valueOf(amount))));
            });
            case TAKE -> plugin.getPointManager().take(uuid, amount).thenAccept(success -> {
                if (Boolean.TRUE.equals(success)) {
                    sender.sendMessage(plugin.getMessage("point-taken", Map.of("amount", String.valueOf(amount), "player", targetName)));
                } else {
                    sender.sendMessage(plugin.getMessage("point-not-enough"));
                }
            });
            case SET -> plugin.getPointManager().set(uuid, amount).thenRun(() ->
                    sender.sendMessage(plugin.getMessage("point-set", Map.of("amount", String.valueOf(amount), "player", targetName))));
        }

        return true;
    }

    private boolean handlePay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtils.colorize("&cChỉ người chơi mới có thể chuyển Point."));
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(ColorUtils.colorize("&cCú pháp: /point pay <player> <amount>"));
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (target.getUniqueId().equals(player.getUniqueId())) {
            sender.sendMessage(ColorUtils.colorize("&cBạn không thể tự chuyển Point cho chính mình."));
            return true;
        }

        Double amount = parseAmount(args[2]);
        if (amount == null || amount <= 0) {
            sender.sendMessage(plugin.getMessage("invalid-amount"));
            return true;
        }

        plugin.getPointManager().pay(player.getUniqueId(), target.getUniqueId(), amount).thenAccept(success -> {
            if (Boolean.TRUE.equals(success)) {
                String targetName = target.getName() != null ? target.getName() : args[1];
                player.sendMessage(plugin.getMessage("point-pay-success", Map.of("amount", String.valueOf(amount), "player", targetName)));
                notifyIfOnline(target, plugin.getMessage("point-pay-received", Map.of("amount", String.valueOf(amount), "sender", player.getName())));
            } else {
                player.sendMessage(plugin.getMessage("point-not-enough"));
            }
        });

        return true;
    }

    private void notifyIfOnline(OfflinePlayer target, String message) {
        if (target.isOnline() && target.getPlayer() != null) {
            target.getPlayer().sendMessage(message);
        }
    }

    private Double parseAmount(String raw) {
        try {
            return Double.parseDouble(raw);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> base = new ArrayList<>(List.of("balance", "pay"));
            if (sender.hasPermission("hyperrank.point.admin")) {
                base.addAll(List.of("give", "take", "set"));
            }
            String prefix = args[0].toLowerCase();
            return base.stream().filter(s -> s.startsWith(prefix)).collect(Collectors.toList());
        }
        if (args.length == 2 && List.of("balance", "pay", "give", "take", "set").contains(args[0].toLowerCase())) {
            String prefix = args[1].toLowerCase();
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase().startsWith(prefix))
                    .collect(Collectors.toList());
        }
        return List.of();
    }
}
