package com.hyperdev.Hyperrank.commands;

import com.hyperdev.Hyperrank.HyperRank;
import com.hyperdev.Hyperrank.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;

public final class RankCommand implements CommandExecutor, TabCompleter {

    private final HyperRank plugin;

    public RankCommand(HyperRank plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("hyperrank.admin")) {
                sender.sendMessage(plugin.getMessage("no-permission"));
                return true;
            }
            plugin.reload();
            sender.sendMessage(plugin.getMessage("reload-success"));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtils.colorize("&cLệnh này chỉ dùng được trong game."));
            return true;
        }

        if (!player.hasPermission("hyperrank.rank.use")) {
            player.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }

        plugin.getRankGUI().open(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && sender.hasPermission("hyperrank.admin")) {
            return List.of("reload");
        }
        return List.of();
    }
}
